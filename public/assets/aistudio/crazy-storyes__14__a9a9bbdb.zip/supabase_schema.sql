-- ============================================================
-- CRAZY STORYES — COMPLETE SUPABASE DATABASE SCHEMA MIGRATION
-- Run this in the Supabase SQL Editor (SQL Editor -> New Query -> Run)
-- ============================================================

-- 1. USERS TABLE
CREATE TABLE IF NOT EXISTS public.users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'reader',
  is_blocked BOOLEAN NOT NULL DEFAULT FALSE,
  membership JSONB NOT NULL DEFAULT '{"isActive": false}'::jsonb,
  bookmarks JSONB NOT NULL DEFAULT '[]'::jsonb,
  reading_history JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Index for fast email lookups and authentication
CREATE INDEX IF NOT EXISTS idx_users_email ON public.users (LOWER(email));
CREATE INDEX IF NOT EXISTS idx_users_role ON public.users (role);

-- 2. NOVELS TABLE
CREATE TABLE IF NOT EXISTS public.novels (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  hindi_title TEXT,
  author TEXT,
  description TEXT NOT NULL,
  cover_image TEXT NOT NULL,
  categories JSONB NOT NULL DEFAULT '["Action"]'::jsonb,
  tags JSONB NOT NULL DEFAULT '[]'::jsonb,
  is_premium BOOLEAN NOT NULL DEFAULT FALSE,
  is_published BOOLEAN NOT NULL DEFAULT TRUE,
  is_featured BOOLEAN NOT NULL DEFAULT FALSE,
  is_trending BOOLEAN NOT NULL DEFAULT FALSE,
  is_popular BOOLEAN NOT NULL DEFAULT FALSE,
  views INTEGER NOT NULL DEFAULT 0,
  rating NUMERIC NOT NULL DEFAULT 5.0,
  rating_count INTEGER NOT NULL DEFAULT 0,
  user_ratings JSONB NOT NULL DEFAULT '{}'::jsonb,
  likes INTEGER NOT NULL DEFAULT 0,
  liked_by JSONB NOT NULL DEFAULT '[]'::jsonb,
  reviews JSONB NOT NULL DEFAULT '[]'::jsonb,
  total_chapters INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_novels_published ON public.novels (is_published);
CREATE INDEX IF NOT EXISTS idx_novels_premium ON public.novels (is_premium);
CREATE INDEX IF NOT EXISTS idx_novels_rating ON public.novels (rating DESC);
CREATE INDEX IF NOT EXISTS idx_novels_views ON public.novels (views DESC);

-- 3. CHAPTERS TABLE
CREATE TABLE IF NOT EXISTS public.chapters (
  id TEXT PRIMARY KEY,
  novel_id TEXT NOT NULL REFERENCES public.novels(id) ON DELETE CASCADE,
  chapter_number INTEGER NOT NULL,
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  audio_url TEXT,
  audio_duration_seconds INTEGER,
  is_premium BOOLEAN NOT NULL DEFAULT FALSE,
  is_published BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_chapters_novel_id ON public.chapters (novel_id);
CREATE INDEX IF NOT EXISTS idx_chapters_number ON public.chapters (novel_id, chapter_number ASC);

-- 4. PAYMENTS TABLE
CREATE TABLE IF NOT EXISTS public.payments (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  user_name TEXT NOT NULL,
  user_email TEXT NOT NULL,
  item_type TEXT NOT NULL,
  item_id TEXT NOT NULL,
  item_name TEXT NOT NULL,
  amount NUMERIC NOT NULL,
  utr_number TEXT,
  payment_proof_url TEXT,
  screenshot_path TEXT,
  status TEXT NOT NULL DEFAULT 'pending', -- 'pending' | 'approved' | 'rejected'
  rejection_reason TEXT,
  admin_note TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  reviewed_at TIMESTAMPTZ,
  reviewed_by TEXT
);

CREATE INDEX IF NOT EXISTS idx_payments_status ON public.payments (status);
CREATE INDEX IF NOT EXISTS idx_payments_user_id ON public.payments (user_id);
CREATE INDEX IF NOT EXISTS idx_payments_created_at ON public.payments (created_at DESC);

-- 5. MEMBERSHIP PLANS TABLE
CREATE TABLE IF NOT EXISTS public.membership_plans (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  hindi_name TEXT NOT NULL,
  price NUMERIC NOT NULL,
  duration_days INTEGER NOT NULL,
  description TEXT NOT NULL,
  features JSONB NOT NULL DEFAULT '[]'::jsonb,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  badge_text TEXT
);

-- 6. SITE SETTINGS TABLE
CREATE TABLE IF NOT EXISTS public.site_settings (
  id TEXT PRIMARY KEY DEFAULT 'current',
  website_name TEXT NOT NULL,
  tagline TEXT NOT NULL,
  admin_email TEXT NOT NULL,
  upi_id TEXT NOT NULL,
  upi_qr_code_url TEXT,
  announcement TEXT,
  announcement_active BOOLEAN NOT NULL DEFAULT TRUE,
  support_email TEXT NOT NULL,
  support_phone TEXT NOT NULL,
  enable_ai_assistant BOOLEAN NOT NULL DEFAULT TRUE,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- 7. SUPPORT TICKETS TABLE
CREATE TABLE IF NOT EXISTS public.support_tickets (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  user_name TEXT NOT NULL,
  user_email TEXT NOT NULL,
  category TEXT NOT NULL,
  subject TEXT NOT NULL,
  message TEXT NOT NULL,
  admin_reply TEXT,
  status TEXT NOT NULL DEFAULT 'open',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  replied_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_tickets_email ON public.support_tickets (LOWER(user_email));
CREATE INDEX IF NOT EXISTS idx_tickets_status ON public.support_tickets (status);

-- Enable Row Level Security (optional - server uses service role key)
ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.novels ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.membership_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.site_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.support_tickets ENABLE ROW LEVEL SECURITY;

-- Allow full access for service_role or backend authenticated service
CREATE POLICY "Full access for service role on users" ON public.users FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Full access for service role on novels" ON public.novels FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Full access for service role on chapters" ON public.chapters FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Full access for service role on payments" ON public.payments FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Full access for service role on membership_plans" ON public.membership_plans FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Full access for service role on site_settings" ON public.site_settings FOR ALL USING (true) WITH CHECK (true);
CREATE POLICY "Full access for service role on support_tickets" ON public.support_tickets FOR ALL USING (true) WITH CHECK (true);
