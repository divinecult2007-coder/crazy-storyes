import React, { useState, useEffect } from 'react';
import { 
  ArrowLeft, 
  ChevronLeft, 
  ChevronRight, 
  Headphones, 
  List, 
  Crown, 
  Lock, 
  Share2, 
  Check, 
  Send,
  ExternalLink,
  BookOpen,
  FileText,
  Download,
  X,
  Type
} from 'lucide-react';
import { Chapter, Novel } from '../types.js';
import { useAuth } from '../context/AuthContext.js';

interface ReaderViewProps {
  novelId: string;
  chapterId: string;
  initialMode?: 'text' | 'audio';
  onBack: () => void;
  onNavigateChapter: (chapterId: string, mode?: 'text' | 'audio') => void;
  onNavigate: (view: string, params?: any) => void;
}

export const ReaderView: React.FC<ReaderViewProps> = ({
  novelId,
  chapterId,
  onBack,
  onNavigateChapter,
  onNavigate
}) => {
  const { user, isVip, token, openPayment } = useAuth();
  const [novel, setNovel] = useState<Novel | null>(null);
  const [allChapters, setAllChapters] = useState<Chapter[]>([]);
  const [currentChapter, setCurrentChapter] = useState<Chapter | null>(null);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [lockReason, setLockReason] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [fontSize, setFontSize] = useState<'sm' | 'base' | 'lg' | 'xl'>('base');
  const [copiedShare, setCopiedShare] = useState<boolean>(false);
  const [telegramAudioLoading, setTelegramAudioLoading] = useState<boolean>(false);

  // Fetch Chapter Content & Novel Info
  const fetchChapterData = () => {
    setLoading(true);

    // Fetch novel details & chapter list
    fetch(`/api/novels/${novelId}`)
      .then((res) => res.json())
      .then((data) => {
        setNovel(data.novel);
        setAllChapters(data.chapters || []);
      })
      .catch((err) => console.error('Error fetching novel details:', err));

    // Fetch current chapter with auth token
    const headers: Record<string, string> = {};
    if (token) headers['Authorization'] = `Bearer ${token}`;

    fetch(`/api/novels/${novelId}/chapters/${chapterId}`, { headers })
      .then((res) => res.json())
      .then((data) => {
        if (data.isLocked) {
          setIsLocked(true);
          setLockReason(data.lockReason || 'यह एक वीआईपी अध्याय है। इसे पढ़ने और सुनने के लिए सक्रिय वीआईपी सदस्यता आवश्यक है।');
          setCurrentChapter(data.chapter);
        } else {
          setIsLocked(false);
          setLockReason('');
          setCurrentChapter(data.chapter);
        }
        setLoading(false);
      })
      .catch((err) => {
        console.error('Error fetching chapter:', err);
        setLoading(false);
      });
  };

  useEffect(() => {
    fetchChapterData();
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [novelId, chapterId, token]);

  // Chapter Navigation
  const currentChapterIndex = allChapters.findIndex((c) => c.id === chapterId);
  const prevChapter = currentChapterIndex > 0 ? allChapters[currentChapterIndex - 1] : null;
  const nextChapter = currentChapterIndex >= 0 && currentChapterIndex < allChapters.length - 1 
    ? allChapters[currentChapterIndex + 1] 
    : null;

  const handlePrevChapter = () => {
    if (prevChapter) {
      onNavigateChapter(prevChapter.id, 'text');
    }
  };

  const handleNextChapter = () => {
    if (nextChapter) {
      onNavigateChapter(nextChapter.id, 'text');
    }
  };

  // Open Telegram Audio for this Chapter
  const handleOpenTelegramAudio = async () => {
    if (!currentChapter) return;
    const isChapterVip = Boolean(currentChapter.isPremium || currentChapter.telegramAudioAccessType === 'premium');
    const hasVipAccess = isVip || user?.role === 'admin';

    if (isChapterVip && !hasVipAccess) {
      openPayment();
      return;
    }

    if (currentChapter.telegramMessageLink) {
      window.open(currentChapter.telegramMessageLink, '_blank', 'noopener,noreferrer');
      return;
    }

    // Call secure chapter audio endpoint
    setTelegramAudioLoading(true);
    try {
      const headers: Record<string, string> = {};
      if (token) headers.Authorization = `Bearer ${token}`;

      const res = await fetch(`/api/telegram/chapters/${currentChapter.id}/audio`, {
        method: 'POST',
        headers
      });
      const data = await res.json();

      if (!res.ok) {
        if (data.code === 'VIP_REQUIRED') {
          openPayment();
          return;
        }
        if (data.code === 'LOGIN_REQUIRED') {
          alert('यह VIP अध्याय है। Telegram ऑडियो सुनने के लिए कृपया लॉगिन करें।');
          return;
        }
        alert(data.error || 'इस अध्याय के लिए Telegram ऑडियो लिंक अभी उपलब्ध नहीं है।');
        return;
      }

      if (data.telegramMessageLink) {
        window.open(data.telegramMessageLink, '_blank', 'noopener,noreferrer');
      } else {
        alert('Telegram ऑडियो लिंक अभी कॉन्फ़िगर नहीं किया गया है।');
      }
    } catch (err: any) {
      alert(err.message || 'Telegram ऑडियो लिंक खोलने में त्रुटि');
    } finally {
      setTelegramAudioLoading(false);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `${currentChapter?.title} - Crazy Storyes`,
        text: `Crazy Storyes पर "${novel?.title || 'उपन्यास'}" का अध्याय पढ़ें!`,
        url: window.location.href
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText(window.location.href);
      setCopiedShare(true);
      setTimeout(() => setCopiedShare(false), 2000);
    }
  };

  const handleDownloadText = (format: 'pdf' | 'txt') => {
    if (isLocked) {
      openPayment();
      return;
    }
    const downloadUrl = `/api/downloads/chapter/${novelId}/${chapterId}/${format}`;
    window.open(downloadUrl, '_blank');
  };

  if (loading) {
    return (
      <div className="py-28 text-center space-y-4">
        <div className="w-14 h-14 border-4 border-purple-500 border-t-amber-400 rounded-full animate-spin mx-auto shadow-[0_0_20px_rgba(168,85,247,0.4)]" />
        <p className="text-sm font-bold text-purple-200 animate-pulse">
          अध्याय लोड हो रहा है...
        </p>
      </div>
    );
  }

  const isChapterVip = Boolean(currentChapter?.isPremium || currentChapter?.telegramAudioAccessType === 'premium');
  const hasVipAccess = isVip || user?.role === 'admin';

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20">
      {/* Top Sticky Header Bar */}
      <div className="sticky top-2 z-20 flex items-center justify-between gap-3 p-3 sm:p-4 rounded-2xl bg-[#14082b]/95 backdrop-blur-md border border-purple-500/30 shadow-xl">
        <button
          onClick={onBack}
          className="btn-3d btn-3d-subtle px-3.5 py-2 rounded-xl text-xs font-bold text-purple-200 flex items-center gap-1.5 hover:text-white"
        >
          <ArrowLeft className="w-4 h-4" />
          <span className="hidden sm:inline">वापस</span>
        </button>

        <div className="text-center min-w-0 px-2 flex-1">
          <h2 className="text-xs sm:text-sm font-black text-white truncate">
            {novel?.title || novel?.hindiTitle || 'Crazy Storyes'}
          </h2>
          <p className="text-[11px] text-amber-400 font-bold truncate">
            अध्याय #{currentChapter?.chapterNumber}: {currentChapter?.title}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {/* Font Size Toggle */}
          <div className="hidden sm:flex items-center bg-purple-950/60 rounded-xl border border-purple-500/30 p-1">
            <button
              onClick={() => setFontSize(fontSize === 'xl' ? 'lg' : fontSize === 'lg' ? 'base' : 'sm')}
              className="px-2 py-1 text-xs text-purple-300 hover:text-white"
              title="फ़ॉन्ट छोटा करें"
            >
              A-
            </button>
            <span className="text-[10px] text-purple-400 px-1 font-mono">
              <Type className="w-3.5 h-3.5" />
            </span>
            <button
              onClick={() => setFontSize(fontSize === 'sm' ? 'base' : fontSize === 'base' ? 'lg' : 'xl')}
              className="px-2 py-1 text-xs text-purple-300 hover:text-white font-bold"
              title="फ़ॉन्ट बड़ा करें"
            >
              A+
            </button>
          </div>

          <button
            onClick={handleShare}
            className="p-2 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-300 hover:text-white transition"
            title="शेयर करें"
          >
            {copiedShare ? <Check className="w-4 h-4 text-emerald-400" /> : <Share2 className="w-4 h-4" />}
          </button>

          <button
            onClick={() => setDrawerOpen(true)}
            className="btn-3d btn-3d-subtle px-3 py-2 rounded-xl text-xs font-bold text-purple-200 flex items-center gap-1.5"
          >
            <List className="w-4 h-4 text-purple-400" />
            <span className="hidden sm:inline">अध्याय सूची</span>
          </button>
        </div>
      </div>

      {/* Prominent Telegram Chapter Audio Action Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-[#0d263b] via-[#10304a] to-[#0a1c2e] border-2 border-[#229ED9]/50 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3 text-left">
          <div className="w-12 h-12 rounded-2xl bg-[#229ED9]/20 border border-[#229ED9]/40 flex items-center justify-center text-[#229ED9] shrink-0 shadow-md">
            <Headphones className="w-6 h-6 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-sm sm:text-base font-black text-white">
                Telegram पर ऑडियो सुनें
              </h3>
              {isChapterVip ? (
                <span className="text-[10px] bg-amber-400 text-amber-950 px-2 py-0.5 rounded-full font-black">
                  VIP AUDIO
                </span>
              ) : (
                <span className="text-[10px] bg-emerald-400 text-emerald-950 px-2 py-0.5 rounded-full font-black">
                  FREE AUDIO
                </span>
              )}
            </div>
            <p className="text-xs text-sky-200/80 mt-0.5">
              इस अध्याय का संपूर्ण वॉयस व ऑडियो एपिसोड Telegram पर उपलब्ध है।
            </p>
          </div>
        </div>

        {isChapterVip && !hasVipAccess ? (
          <button
            onClick={() => openPayment()}
            className="btn-3d btn-3d-gold px-5 py-2.5 rounded-xl font-black text-xs sm:text-sm text-amber-950 flex items-center gap-2 shadow-lg shrink-0 hover:scale-105 transition-all"
          >
            <Lock className="w-4 h-4" />
            <span>UNLOCK VIP AUDIO</span>
          </button>
        ) : (
          <button
            onClick={handleOpenTelegramAudio}
            disabled={telegramAudioLoading}
            className="btn-3d bg-gradient-to-r from-[#229ED9] to-[#0088cc] hover:from-[#29b6f6] hover:to-[#0288d1] text-white px-6 py-2.5 rounded-xl font-black text-xs sm:text-sm flex items-center gap-2 shadow-lg shrink-0 hover:scale-105 transition-all disabled:opacity-50"
          >
            <Send className="w-4 h-4" />
            <span>
              {telegramAudioLoading ? 'खुल रहा है...' : isChapterVip ? 'LISTEN ON TELEGRAM' : 'LISTEN FREE ON TELEGRAM'}
            </span>
            <ExternalLink className="w-3.5 h-3.5 opacity-80" />
          </button>
        )}
      </div>

      {/* Reader Content Area */}
      <div className="rounded-3xl bg-gradient-to-b from-[#14082b] to-[#0c0419] border border-purple-500/30 p-6 sm:p-10 shadow-2xl space-y-6">
        {isLocked ? (
          /* Locked Chapter Card */
          <div className="max-w-md mx-auto py-12 text-center space-y-5">
            <div className="w-16 h-16 rounded-3xl bg-amber-500/20 text-amber-400 border border-amber-500/40 flex items-center justify-center mx-auto shadow-lg">
              <Lock className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h3 className="text-xl font-black text-white">यह एक वीआईपी अध्याय है</h3>
              <p className="text-xs sm:text-sm text-purple-200/90 leading-relaxed">
                {lockReason}
              </p>
            </div>

            <button
              onClick={() => openPayment()}
              className="btn-3d btn-3d-gold w-full py-3.5 rounded-2xl font-black text-sm text-amber-950 flex items-center justify-center gap-2 shadow-xl hover:scale-105 transition-transform"
            >
              <Crown className="w-5 h-5 fill-amber-950" />
              <span>🌟 अभी VIP सदस्यता अनलॉक करें (Unlock Now)</span>
            </button>
          </div>
        ) : (
          /* Unlocked Text Reading Experience */
          <div className="space-y-6">
            {/* Title Header */}
            <div className="border-b border-purple-900/50 pb-5 text-center sm:text-left space-y-2">
              <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2">
                <span className="px-2.5 py-0.5 rounded-md bg-purple-900/70 border border-purple-500/30 text-xs font-mono font-bold text-purple-200">
                  अध्याय #{currentChapter?.chapterNumber}
                </span>
                {isChapterVip ? (
                  <span className="px-2.5 py-0.5 rounded-md bg-amber-500/20 border border-amber-500/40 text-xs font-bold text-amber-300">
                    👑 VIP
                  </span>
                ) : (
                  <span className="px-2.5 py-0.5 rounded-md bg-emerald-500/20 border border-emerald-500/40 text-xs font-bold text-emerald-300">
                    नि:शुल्क
                  </span>
                )}
              </div>
              <h1 className="text-2xl sm:text-3xl font-black text-white leading-tight">
                {currentChapter?.title}
              </h1>
            </div>

            {/* Reading Text Content */}
            <div
              className={`leading-relaxed text-purple-100 font-normal whitespace-pre-line tracking-wide select-text space-y-4 ${
                fontSize === 'sm'
                  ? 'text-sm leading-6'
                  : fontSize === 'base'
                  ? 'text-base leading-7 sm:text-lg sm:leading-8'
                  : fontSize === 'lg'
                  ? 'text-lg leading-8 sm:text-xl sm:leading-9'
                  : 'text-xl leading-9 sm:text-2xl sm:leading-10'
              }`}
            >
              {currentChapter?.content || 'इस अध्याय में अभी कोई लिखित सामग्री उपलब्ध नहीं है।'}
            </div>

            {/* Bottom Actions: Download Text */}
            <div className="pt-6 border-t border-purple-900/40 flex flex-wrap items-center justify-between gap-3 text-xs">
              <div className="flex items-center gap-2 text-purple-400">
                <BookOpen className="w-4 h-4 text-purple-400" />
                <span>अध्याय समाप्त • अगला अध्याय पढ़ें या Telegram पर ऑडियो सुनें</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleDownloadText('pdf')}
                  className="px-3 py-1.5 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-200 hover:text-white flex items-center gap-1.5 transition"
                  title="PDF डाउनलोड करें"
                >
                  <Download className="w-3.5 h-3.5 text-purple-400" />
                  <span>PDF</span>
                </button>
                <button
                  onClick={() => handleDownloadText('txt')}
                  className="px-3 py-1.5 rounded-xl bg-purple-950/60 border border-purple-500/30 text-purple-200 hover:text-white flex items-center gap-1.5 transition"
                  title="TXT डाउनलोड करें"
                >
                  <FileText className="w-3.5 h-3.5 text-purple-400" />
                  <span>TXT</span>
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Bottom Chapter Prev / Next Navigation Bar */}
        <div className="flex items-center justify-between gap-3 pt-4 border-t border-purple-900/40">
          <button
            onClick={handlePrevChapter}
            disabled={!prevChapter}
            className="btn-3d btn-3d-subtle px-4 py-2.5 rounded-xl text-xs font-bold text-purple-200 flex items-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed hover:text-white"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>पिछला अध्याय</span>
          </button>

          <button
            onClick={() => setDrawerOpen(true)}
            className="text-xs text-purple-300 font-semibold hover:text-white"
          >
            अध्याय {currentChapterIndex + 1} / {allChapters.length}
          </button>

          <button
            onClick={handleNextChapter}
            disabled={!nextChapter}
            className="btn-3d btn-3d-subtle px-4 py-2.5 rounded-xl text-xs font-bold text-purple-200 flex items-center gap-2 disabled:opacity-30 disabled:cursor-not-allowed hover:text-white"
          >
            <span>अगला अध्याय</span>
            <ChevronRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Chapters Drawer / Slide-out List */}
      {drawerOpen && (
        <div className="fixed inset-0 z-50 flex justify-end bg-black/80 backdrop-blur-sm animate-in fade-in duration-200">
          <div className="w-full max-w-md h-full bg-[#120726] border-l border-purple-500/30 p-5 flex flex-col space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-purple-900/40">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <List className="w-5 h-5 text-purple-400" />
                <span>अध्याय सूची ({allChapters.length})</span>
              </h3>
              <button
                onClick={() => setDrawerOpen(false)}
                className="p-1.5 rounded-lg bg-black/40 text-purple-300 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {allChapters.map((ch) => {
                const isCurrent = ch.id === chapterId;
                const isChVip = Boolean(ch.isPremium || ch.telegramAudioAccessType === 'premium');

                return (
                  <div
                    key={ch.id}
                    onClick={() => {
                      setDrawerOpen(false);
                      onNavigateChapter(ch.id, 'text');
                    }}
                    className={`p-3 rounded-xl border cursor-pointer transition-all flex items-center justify-between gap-2 ${
                      isCurrent
                        ? 'bg-purple-600/30 border-amber-400 text-white shadow-md'
                        : 'bg-purple-950/40 border-purple-500/20 text-purple-200 hover:bg-purple-900/40'
                    }`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 font-bold text-xs ${
                          isCurrent
                            ? 'bg-amber-500 text-amber-950'
                            : 'bg-purple-900 text-purple-300'
                        }`}
                      >
                        #{ch.chapterNumber}
                      </div>

                      <div className="min-w-0">
                        <p className={`text-xs font-bold truncate ${isCurrent ? 'text-amber-300' : 'text-white'}`}>
                          {ch.title}
                        </p>
                        <span className="text-[10px] text-purple-400">
                          {isChVip ? '👑 VIP' : 'Free'}
                        </span>
                      </div>
                    </div>

                    <div className="shrink-0 flex items-center gap-1.5">
                      {isCurrent ? (
                        <span className="px-2 py-0.5 rounded-full bg-amber-500 text-amber-950 text-[10px] font-black flex items-center gap-1">
                          पढ़ रहे हैं
                        </span>
                      ) : isChVip ? (
                        <span className="vip-badge-3d px-2 py-0.5 rounded-full text-[10px] font-bold text-amber-950 flex items-center gap-0.5">
                          <Crown className="w-2.5 h-2.5" /> VIP
                        </span>
                      ) : (
                        <span className="free-badge-3d px-2 py-0.5 rounded-full text-[10px] font-bold text-white">
                          Free
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
