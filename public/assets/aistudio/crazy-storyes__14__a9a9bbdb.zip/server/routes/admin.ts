import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { db, UPLOADS_DIR, PRIVATE_SCREENSHOTS_DIR } from '../db.js';
import { requireAdmin, AuthRequest } from '../auth.js';
import { Novel, Chapter } from '../types.js';
import { supabase, checkSupabaseConnection } from '../supabase.js';
import { telegramService } from '../telegram.js';

const router = express.Router();

// Multer storage for uploads (images & audio)
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const unique = `${Date.now()}_${Math.random().toString(36).substring(2, 8)}`;
    cb(null, `${unique}${ext}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 50 * 1024 * 1024 } // 50MB max for audio/images
});

// All routes in /api/admin require authenticated Admin
router.use(requireAdmin);

// -------------------------------------------------------------
// Live Supabase Health & Connection Verification Endpoint
// -------------------------------------------------------------
router.get('/supabase-status', async (req, res) => {
  try {
    const health = await checkSupabaseConnection();
    return res.json(health);
  } catch (err: any) {
    return res.status(500).json({
      configured: false,
      connected: false,
      error: err.message || 'Supabase कनेक्शन जांच में त्रुटि'
    });
  }
});

// -------------------------------------------------------------
// 1. Dashboard Statistics
// -------------------------------------------------------------
router.get('/stats', async (req, res) => {
  try {
    const [users, novels, chapters, payments, supabaseHealth] = await Promise.all([
      db.getUsers(),
      db.getNovels(),
      db.getChapters(),
      db.getPayments(),
      checkSupabaseConnection().catch(() => null)
    ]);

    const totalUsers = users.length;
    const totalNovels = novels.length;
    const totalChapters = chapters.length;
    const premiumMembers = users.filter(u => u.membership?.isActive).length;
    const pendingPayments = payments.filter(p => p.status === 'pending').length;
    const totalRevenue = payments
      .filter(p => p.status === 'approved')
      .reduce((sum, p) => sum + (Number(p.amount) || 0), 0);

    return res.json({
      totalUsers,
      totalNovels,
      totalChapters,
      premiumMembers,
      pendingPayments,
      totalRevenue,
      supabaseHealth
    });
  } catch (err) {
    console.error('Stats error:', err);
    return res.status(500).json({ error: 'डैशबोर्ड आंकड़े लोड करने में त्रुटि' });
  }
});

// -------------------------------------------------------------
// 2. Novel Management CRUD
// -------------------------------------------------------------
router.post('/novels', async (req, res) => {
  try {
    const {
      title,
      hindiTitle,
      author,
      description,
      coverImage,
      categories,
      tags,
      isPremium,
      isPublished,
      isFeatured,
      telegramChannelId,
      telegramChannelName,
      telegramChannelType,
      telegramAccessType,
      telegramIntegrationEnabled
    } = req.body;

    if (!title || !description || !coverImage) {
      return res.status(400).json({ error: 'शीर्षक, विवरण और 16:9 कवर इमेज आवश्यक हैं' });
    }

    const newNovel: Novel = {
      id: `novel_${Date.now()}`,
      title: title.trim(),
      hindiTitle: hindiTitle ? hindiTitle.trim() : undefined,
      author: (author || '').trim(),
      description: description.trim(),
      coverImage: coverImage.trim(),
      categories: Array.isArray(categories) && categories.length > 0 ? categories : ['Action'],
      tags: Array.isArray(tags) ? tags : [],
      isPremium: Boolean(isPremium),
      isPublished: isPublished !== false,
      isFeatured: Boolean(isFeatured),
      isTrending: false,
      isPopular: false,
      views: 0,
      rating: 5.0,
      ratingCount: 0,
      totalChapters: 0,
      telegramChannelId: telegramChannelId ? telegramChannelId.trim() : undefined,
      telegramChannelName: telegramChannelName ? telegramChannelName.trim() : undefined,
      telegramChannelType: telegramChannelType || 'channel',
      telegramAccessType: telegramAccessType || (isPremium ? 'vip' : 'free'),
      telegramIntegrationEnabled: Boolean(telegramIntegrationEnabled),
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const saved = await db.addNovel(newNovel);
    return res.status(201).json({ message: 'उपन्यास सफलतापूर्वक जोड़ा गया', novel: saved });
  } catch (err) {
    console.error('Add novel error:', err);
    return res.status(500).json({ error: 'उपन्यास जोड़ने में विफलता' });
  }
});

router.put('/novels/:id', async (req, res) => {
  try {
    const novelId = req.params.id;
    const existing = await db.getNovelById(novelId);
    if (!existing) return res.status(404).json({ error: 'उपन्यास नहीं मिला' });

    const updated = await db.updateNovel(novelId, req.body);
    return res.json({ message: 'उपन्यास अपडेट हुआ', novel: updated });
  } catch (err) {
    console.error('Update novel error:', err);
    return res.status(500).json({ error: 'उपन्यास अपडेट में विफलता' });
  }
});

router.put('/novels/:id/toggle-premium', async (req, res) => {
  try {
    const novel = await db.getNovelById(req.params.id);
    if (!novel) return res.status(404).json({ error: 'उपन्यास नहीं मिला' });

    const updated = await db.updateNovel(novel.id, { isPremium: !novel.isPremium });
    return res.json({ message: `उपन्यास ${updated?.isPremium ? 'VIP' : 'FREE'} किया गया`, novel: updated });
  } catch (err) {
    console.error('Toggle novel premium error:', err);
    return res.status(500).json({ error: 'प्रीमियम स्थिति बदलने में विफलता' });
  }
});

router.put('/novels/:id/toggle-publish', async (req, res) => {
  try {
    const novel = await db.getNovelById(req.params.id);
    if (!novel) return res.status(404).json({ error: 'उपन्यास नहीं मिला' });

    const updated = await db.updateNovel(novel.id, { isPublished: !novel.isPublished });
    return res.json({ message: `उपन्यास ${updated?.isPublished ? 'प्रकाशित' : 'अप्रकाशित'} किया गया`, novel: updated });
  } catch (err) {
    console.error('Toggle novel publish error:', err);
    return res.status(500).json({ error: 'प्रकाशन स्थिति बदलने में विफलता' });
  }
});

router.delete('/novels/:id', async (req, res) => {
  try {
    const success = await db.deleteNovel(req.params.id);
    if (!success) return res.status(404).json({ error: 'उपन्यास नहीं मिला' });
    return res.json({ message: 'उपन्यास और उसके सभी अध्याय हटा दिए गए' });
  } catch (err) {
    console.error('Delete novel error:', err);
    return res.status(500).json({ error: 'उपन्यास हटाने में विफलता' });
  }
});

// -------------------------------------------------------------
// 3. Chapter Management CRUD
// -------------------------------------------------------------
router.get('/novels/:novelId/chapters', async (req, res) => {
  try {
    const chapters = await db.getChapters(req.params.novelId);
    return res.json({ chapters });
  } catch (err) {
    console.error('Get chapters error:', err);
    return res.status(500).json({ error: 'अध्याय लोड करने में त्रुटि' });
  }
});

router.post('/chapters', async (req, res) => {
  try {
    const {
      novelId,
      chapterNumber,
      title,
      content,
      isPremium,
      isPublished,
      telegramMessageLink,
      telegramMessageId,
      telegramChatId,
      telegramDestinationType,
      telegramAudioAccessType
    } = req.body;

    if (!novelId || !title) {
      return res.status(400).json({ error: 'novelId और अध्याय शीर्षक आवश्यक हैं' });
    }

    const novel = await db.getNovelById(novelId);
    if (!novel) return res.status(404).json({ error: 'संबंधित उपन्यास नहीं मिला' });

    const cleanTgLink = telegramMessageLink ? String(telegramMessageLink).trim() : undefined;
    const cleanTgMsgId = telegramMessageId ? Number(telegramMessageId) : undefined;
    const cleanTgChatId = telegramChatId ? String(telegramChatId).trim() : undefined;
    const isConfigured = Boolean(cleanTgLink);

    const newChapter: Chapter = {
      id: `ch_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      novelId,
      chapterNumber: Number(chapterNumber) || (novel.totalChapters + 1),
      title: title.trim(),
      content: (content || '').trim(),
      telegramMessageLink: cleanTgLink,
      telegramMessageId: cleanTgMsgId,
      telegramChatId: cleanTgChatId,
      telegramDestinationType: telegramDestinationType || 'channel',
      telegramAudioAccessType: telegramAudioAccessType || (isPremium ? 'premium' : 'free'),
      telegramAudioConfigured: isConfigured,
      isPremium: Boolean(isPremium),
      isPublished: isPublished !== false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    const saved = await db.addChapter(newChapter);
    return res.status(201).json({ message: 'अध्याय सफलतापूर्वक जोड़ा गया', chapter: saved });
  } catch (err) {
    console.error('Add chapter error:', err);
    return res.status(500).json({ error: 'अध्याय जोड़ने में विफलता' });
  }
});

router.put('/chapters/:id', async (req, res) => {
  try {
    const chapterId = req.params.id;
    const existing = await db.getChapterById(chapterId);
    if (!existing) return res.status(404).json({ error: 'अध्याय नहीं मिला' });

    const payload: Partial<Chapter> = { ...req.body };
    if (payload.chapterNumber !== undefined) {
      payload.chapterNumber = Number(payload.chapterNumber);
    }
    if (payload.isPremium !== undefined) {
      payload.isPremium = Boolean(payload.isPremium);
    }
    if (payload.isPublished !== undefined) {
      payload.isPublished = Boolean(payload.isPublished);
    }
    if (payload.telegramMessageLink !== undefined) {
      payload.telegramMessageLink = payload.telegramMessageLink ? String(payload.telegramMessageLink).trim() : undefined;
      payload.telegramAudioConfigured = Boolean(payload.telegramMessageLink);
    }
    if (payload.telegramMessageId !== undefined) {
      payload.telegramMessageId = payload.telegramMessageId ? Number(payload.telegramMessageId) : undefined;
    }
    if (payload.telegramChatId !== undefined) {
      payload.telegramChatId = payload.telegramChatId ? String(payload.telegramChatId).trim() : undefined;
    }

    const updated = await db.updateChapter(chapterId, payload);
    return res.json({ message: 'अध्याय अपडेट हुआ', chapter: updated });
  } catch (err) {
    console.error('Update chapter error:', err);
    return res.status(500).json({ error: 'अध्याय अपडेट में विफलता' });
  }
});

// Quick Update Chapter Telegram Audio Link
router.put('/chapters/:id/telegram-link', async (req, res) => {
  try {
    const chapterId = req.params.id;
    const existing = await db.getChapterById(chapterId);
    if (!existing) return res.status(404).json({ error: 'अध्याय नहीं मिला' });

    const { telegramMessageLink, telegramMessageId, telegramChatId, telegramDestinationType, telegramAudioAccessType } = req.body;
    const cleanLink = telegramMessageLink !== undefined ? (telegramMessageLink ? String(telegramMessageLink).trim() : '') : (existing.telegramMessageLink || '');

    const updated = await db.updateChapter(chapterId, {
      telegramMessageLink: cleanLink || undefined,
      telegramMessageId: telegramMessageId !== undefined ? (telegramMessageId ? Number(telegramMessageId) : undefined) : existing.telegramMessageId,
      telegramChatId: telegramChatId !== undefined ? (telegramChatId ? String(telegramChatId).trim() : undefined) : existing.telegramChatId,
      telegramDestinationType: telegramDestinationType || existing.telegramDestinationType || 'channel',
      telegramAudioAccessType: telegramAudioAccessType || existing.telegramAudioAccessType || (existing.isPremium ? 'premium' : 'free'),
      telegramAudioConfigured: Boolean(cleanLink),
      updatedAt: new Date().toISOString()
    });

    return res.json({ message: 'अध्याय का Telegram ऑडियो लिंक अपडेट किया गया', chapter: updated });
  } catch (err: any) {
    console.error('Update chapter telegram link error:', err);
    return res.status(500).json({ error: err.message || 'Telegram ऑडियो लिंक अपडेट में विफलता' });
  }
});

router.put('/chapters/:id/toggle-premium', async (req, res) => {
  try {
    const chapter = await db.getChapterById(req.params.id);
    if (!chapter) return res.status(404).json({ error: 'अध्याय नहीं मिला' });

    const updated = await db.updateChapter(chapter.id, { isPremium: !chapter.isPremium });
    return res.json({ message: `अध्याय ${updated?.isPremium ? 'VIP' : 'FREE'} किया गया`, chapter: updated });
  } catch (err) {
    console.error('Toggle chapter premium error:', err);
    return res.status(500).json({ error: 'अध्याय प्रीमियम स्थिति बदलने में विफलता' });
  }
});

router.put('/chapters/:id/toggle-publish', async (req, res) => {
  try {
    const chapter = await db.getChapterById(req.params.id);
    if (!chapter) return res.status(404).json({ error: 'अध्याय नहीं मिला' });

    const updated = await db.updateChapter(chapter.id, { isPublished: !chapter.isPublished });
    return res.json({ message: `अध्याय ${updated?.isPublished ? 'प्रकाशित' : 'अप्रकाशित'} किया गया`, chapter: updated });
  } catch (err) {
    console.error('Toggle chapter publish error:', err);
    return res.status(500).json({ error: 'अध्याय प्रकाशन स्थिति बदलने में विफलता' });
  }
});

router.delete('/chapters/:id', async (req, res) => {
  try {
    const success = await db.deleteChapter(req.params.id);
    if (!success) return res.status(404).json({ error: 'अध्याय नहीं मिला' });
    return res.json({ message: 'अध्याय हटा दिया गया' });
  } catch (err) {
    console.error('Delete chapter error:', err);
    return res.status(500).json({ error: 'अध्याय हटाने में विफलता' });
  }
});

// -------------------------------------------------------------
// 4. User Management & Role Updates
// -------------------------------------------------------------
router.get('/users', async (req, res) => {
  try {
    const { q } = req.query as { q?: string };
    let users = await db.getUsers();

    if (q && q.trim()) {
      const term = q.trim().toLowerCase();
      users = users.filter(u => u.name.toLowerCase().includes(term) || u.email.toLowerCase().includes(term));
    }

    const safeUsers = users.map(u => ({
      id: u.id,
      name: u.name,
      email: u.email,
      role: u.role,
      isBlocked: u.isBlocked,
      membership: u.membership,
      lastLoginAt: u.lastLoginAt,
      lastLogoutAt: u.lastLogoutAt,
      createdAt: u.createdAt
    }));

    return res.json({ users: safeUsers });
  } catch (err) {
    console.error('Get users error:', err);
    return res.status(500).json({ error: 'उपयोगकर्ता लोड करने में त्रुटि' });
  }
});

// Role Update (Admin <-> Reader)
router.put('/users/:id/role', async (req, res) => {
  try {
    const { role } = req.body;
    if (role !== 'admin' && role !== 'reader') {
      return res.status(400).json({ error: 'अमान्य रोल। केवल admin या reader मान्य हैं।' });
    }

    const user = await db.getUserById(req.params.id);
    if (!user) return res.status(404).json({ error: 'उपयोगकर्ता नहीं मिला' });

    const settings = await db.getSettings();
    const ownerEmail = (settings.adminEmail || '').toLowerCase();
    const isOwner =
      user.email.toLowerCase() === ownerEmail ||
      user.email.toLowerCase() === 'divinecult2007@gmail.com' ||
      user.email.toLowerCase() === 'ganish9784@gmail.com';

    // Prevent demoting the owner account
    if (isOwner && role !== 'admin') {
      return res.status(400).json({ error: 'वेबसाइट स्वामी (Owner) के एडमिन रोल को हटाया नहीं जा सकता।' });
    }

    const updated = await db.updateUser(user.id, { role });
    return res.json({
      message: `उपयोगकर्ता रोल बदलकर ${role === 'admin' ? 'ADMIN (व्यवस्थापक)' : 'READER (पाठक)'} कर दिया गया।`,
      user: {
        id: updated?.id,
        name: updated?.name,
        email: updated?.email,
        role: updated?.role,
        membership: updated?.membership,
        isBlocked: updated?.isBlocked
      }
    });
  } catch (err) {
    console.error('Update user role error:', err);
    return res.status(500).json({ error: 'रोल बदलने में विफलता' });
  }
});

// Block / Unblock User
router.put('/users/:id/block', async (req, res) => {
  try {
    const { isBlocked } = req.body;
    const user = await db.getUserById(req.params.id);
    if (!user) return res.status(404).json({ error: 'उपयोगकर्ता नहीं मिला' });

    const settings = await db.getSettings();
    const ownerEmail = (settings.adminEmail || '').toLowerCase();
    const isOwner =
      user.email.toLowerCase() === ownerEmail ||
      user.email.toLowerCase() === 'divinecult2007@gmail.com' ||
      user.email.toLowerCase() === 'ganish9784@gmail.com';

    if (isOwner) {
      return res.status(400).json({ error: 'वेबसाइट स्वामी (Owner) के खाते को ब्लॉक नहीं किया जा सकता।' });
    }

    const updated = await db.updateUser(user.id, { isBlocked: Boolean(isBlocked) });
    return res.json({
      message: isBlocked ? 'खाता अवरुद्ध (Blocked) कर दिया गया' : 'खाता सक्रिय (Unblocked) किया गया',
      user: updated
    });
  } catch (err) {
    console.error('Block user error:', err);
    return res.status(500).json({ error: 'खाता स्थिति बदलने में विफलता' });
  }
});

// Membership Grant / Revoke
router.put('/users/:id/membership', async (req, res) => {
  try {
    const { isActive, durationDays, planName } = req.body;
    const user = await db.getUserById(req.params.id);
    if (!user) return res.status(404).json({ error: 'उपयोगकर्ता नहीं मिला' });

    let expiresAt: string | undefined = undefined;
    let expiresEpoch: number | undefined = undefined;
    if (isActive) {
      const days = Number(durationDays) || 30;
      expiresEpoch = Date.now() + days * 86400000;
      expiresAt = new Date(expiresEpoch).toISOString();
    }

    const updatedMembership = {
      isActive: Boolean(isActive),
      planName: isActive ? (planName || 'Admin Granted VIP') : undefined,
      expiresAt
    };

    const updated = await db.updateUser(user.id, {
      membership: updatedMembership
    });
    return res.json({ message: 'उपयोगकर्ता सदस्यता अपडेट हुई', membership: updated?.membership });
  } catch (err) {
    console.error('Membership update error:', err);
    return res.status(500).json({ error: 'सदस्यता अपडेट में विफलता' });
  }
});

// -------------------------------------------------------------
// 5. Payment & UTR Verification Management
// -------------------------------------------------------------
router.get('/payments', async (req, res) => {
  try {
    const payments = await db.getPayments();
    return res.json({ payments });
  } catch (err) {
    console.error('Get payments error:', err);
    return res.status(500).json({ error: 'भुगतान रिकॉर्ड लोड करने में त्रुटि' });
  }
});

// Approve Payment & Instantly Upgrade Membership in Supabase
router.put('/payments/:id/approve', async (req: AuthRequest, res) => {
  try {
    const payment = await db.getPaymentById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'पेमेंट रिकॉर्ड नहीं मिला' });
    if (payment.status === 'approved') return res.status(400).json({ error: 'यह पेमेंट पहले ही स्वीकृत हो चुकी है' });

    payment.status = 'approved';
    payment.reviewedAt = new Date().toISOString();
    payment.reviewedBy = req.user?.email || 'admin';
    const updatedPayment = await db.updatePayment(payment.id, payment);

    // Automatically activate VIP membership for the user in Supabase
    const user = await db.getUserById(payment.userId);
    let updatedUser = null;
    if (user) {
      const plans = await db.getPlans();
      const matchedPlan = plans.find(p => p.id === payment.itemId) || plans.find(p => p.price === payment.amount);
      const durationDays = matchedPlan ? matchedPlan.durationDays : 30;
      const expiresAt = new Date(Date.now() + durationDays * 86400000).toISOString();

      const expiresEpoch = Date.now() + durationDays * 86400000;
      const membership = {
        isActive: true,
        planId: matchedPlan?.id,
        planName: payment.itemName,
        expiresAt
      };
      updatedUser = await db.updateUser(user.id, {
        membership
      });

      // If user has linked Telegram, notify them instantly
      if (user.telegram?.telegramUserId) {
        telegramService.sendMessage(
          user.telegram.telegramUserId,
          `🎉 <b>बधाई हो! आपकी VIP सदस्यता सक्रिय हो गई है!</b>\n\n` +
          `💰 <b>स्वीकृत प्लान:</b> ${payment.itemName} (₹${payment.amount})\n` +
          `📅 <b>वैधता:</b> ${new Date(expiresEpoch).toLocaleDateString('hi-IN')}\n\n` +
          `🚀 अब आप वेबसाइट पर किसी भी VIP ऑडियो उपन्यास के पेज पर जाकर 'Listen on Telegram' बटन से आधिकारिक चैनल से जुड़ सकते हैं!`
        ).catch((err) => console.error('Error sending Telegram approval notification:', err));
      }
    }

    return res.json({
      message: 'पेमेंट स्वीकृत! वीआईपी सदस्यता तत्काल सक्रिय कर दी गई है। (Payment approved & VIP activated)',
      payment: updatedPayment,
      userMembership: updatedUser?.membership
    });
  } catch (err) {
    console.error('Approve payment error:', err);
    return res.status(500).json({ error: 'पेमेंट स्वीकृत करने में विफलता' });
  }
});

// Reject Payment with Reason saved to Supabase
router.put('/payments/:id/reject', async (req: AuthRequest, res) => {
  try {
    const { reason } = req.body;
    const payment = await db.getPaymentById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'पेमेंट रिकॉर्ड नहीं मिला' });

    const rejectionReason = (reason || 'भुगतान सत्यापित नहीं हो सका (UTR/स्क्रीनशॉट अमान्य)').trim();

    payment.status = 'rejected';
    payment.rejectionReason = rejectionReason;
    payment.reviewedAt = new Date().toISOString();
    payment.reviewedBy = req.user?.email || 'admin';
    const updatedPayment = await db.updatePayment(payment.id, payment);

    return res.json({
      message: 'पेमेंट अस्वीकृत किया गया (Payment rejected)',
      payment: updatedPayment
    });
  } catch (err) {
    console.error('Reject payment error:', err);
    return res.status(500).json({ error: 'पेमेंट अस्वीकृत करने में विफलता' });
  }
});

// Request Additional Payment Information
router.put('/payments/:id/request-info', async (req: AuthRequest, res) => {
  try {
    const { note } = req.body;
    const payment = await db.getPaymentById(req.params.id);
    if (!payment) return res.status(404).json({ error: 'पेमेंट रिकॉर्ड नहीं मिला' });

    const adminNote = (note || 'कृपया स्पष्ट भुगतान स्क्रीनशॉट या 12 अंकों का UTR नंबर प्रदान करें').trim();

    payment.adminNote = adminNote;
    payment.reviewedAt = new Date().toISOString();
    payment.reviewedBy = req.user?.email || 'admin';
    const updatedPayment = await db.updatePayment(payment.id, payment);

    return res.json({
      message: 'अतिरिक्त जानकारी का अनुरोध भेजा गया',
      payment: updatedPayment
    });
  } catch (err) {
    console.error('Request info error:', err);
    return res.status(500).json({ error: 'जानकारी अनुरोध भेजने में विफलता' });
  }
});

// Serve private payment screenshot securely to Admin
router.get('/payments/:id/screenshot', async (req: AuthRequest, res) => {
  try {
    const payment = await db.getPaymentById(req.params.id);
    if (!payment || !payment.screenshotPath) {
      return res.status(404).json({ error: 'स्क्रीनशॉट नहीं मिला' });
    }
    const safeName = path.basename(payment.screenshotPath);
    const fullPath = path.join(PRIVATE_SCREENSHOTS_DIR, safeName);
    if (!fs.existsSync(fullPath)) {
      return res.status(404).json({ error: 'स्क्रीनशॉट फ़ाइल सर्वर पर उपलब्ध नहीं है' });
    }
    return res.sendFile(fullPath);
  } catch (err) {
    console.error('Get screenshot error:', err);
    return res.status(500).json({ error: 'स्क्रीनशॉट लोड करने में त्रुटि' });
  }
});

// -------------------------------------------------------------
// 6. Settings & Membership Plans
// -------------------------------------------------------------
router.get('/settings', async (req, res) => {
  try {
    const [settings, plans] = await Promise.all([
      db.getSettings(),
      db.getPlans()
    ]);
    return res.json({ settings, plans });
  } catch (err) {
    console.error('Get settings error:', err);
    return res.status(500).json({ error: 'सेटिंग्स लोड करने में त्रुटि' });
  }
});

router.put('/settings', async (req, res) => {
  try {
    const updated = await db.updateSettings(req.body);
    return res.json({ message: 'सेटिंग्स सफलतापूर्वक सहेजी गईं', settings: updated });
  } catch (err) {
    console.error('Update settings error:', err);
    return res.status(500).json({ error: 'सेटिंग्स अपडेट में विफलता' });
  }
});

router.put('/plans', async (req, res) => {
  try {
    const { plans } = req.body;
    if (!Array.isArray(plans)) return res.status(400).json({ error: 'अमान्य प्लान डेटा' });
    const updated = await db.updatePlans(plans);
    return res.json({ message: 'सदस्यता प्लान अपडेट हुए', plans: updated });
  } catch (err) {
    console.error('Update plans error:', err);
    return res.status(500).json({ error: 'प्लान अपडेट में विफलता' });
  }
});

// -------------------------------------------------------------
// 7. File Uploads (Covers & Audio)
// -------------------------------------------------------------
router.post('/upload-image', upload.single('image'), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'कोई इमेज फाइल नहीं मिली' });
  }

  // If Supabase client is initialized, attempt direct upload to bucket 'crazy-storyes-assets'
  if (supabase) {
    try {
      const fileBuffer = fs.readFileSync(req.file.path);
      const ext = path.extname(req.file.originalname).toLowerCase() || '.jpg';
      const storageKey = `covers/${Date.now()}_${Math.random().toString(36).substring(2, 8)}${ext}`;

      const { data, error } = await supabase.storage
        .from('crazy-storyes-assets')
        .upload(storageKey, fileBuffer, {
          contentType: req.file.mimetype || 'image/jpeg',
          upsert: true
        });

      if (!error && data) {
        const { data: pubData } = supabase.storage
          .from('crazy-storyes-assets')
          .getPublicUrl(storageKey);

        if (pubData?.publicUrl) {
          return res.json({
            url: pubData.publicUrl,
            storage: 'supabase',
            filename: req.file.filename
          });
        }
      } else if (error) {
        console.warn('Supabase storage upload info (falling back to local):', error.message);
      }
    } catch (err) {
      console.warn('Supabase storage exception (falling back to local):', err);
    }
  }

  const fileUrl = `/uploads/${req.file.filename}`;
  return res.json({ url: fileUrl, filename: req.file.filename, storage: 'local' });
});

router.post('/upload-audio', upload.single('audio'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'कोई ऑडियो फाइल नहीं मिली' });
  }
  const fileUrl = `/uploads/${req.file.filename}`;
  return res.json({ url: fileUrl, filename: req.file.filename });
});

// -------------------------------------------------------------
// 8. Support Tickets
// -------------------------------------------------------------
router.get('/tickets', async (req, res) => {
  try {
    const tickets = await db.getSupportTickets();
    return res.json({ tickets });
  } catch (err) {
    console.error('Get tickets error:', err);
    return res.status(500).json({ error: 'टिकट लोड करने में त्रुटि' });
  }
});

router.put('/tickets/:id/reply', async (req, res) => {
  try {
    const { reply } = req.body;
    if (!reply) return res.status(400).json({ error: 'उत्तर आवश्यक है' });

    const ticket = await db.updateSupportTicket(req.params.id, {
      adminReply: reply.trim(),
      status: 'answered',
      repliedAt: new Date().toISOString()
    });

    if (!ticket) return res.status(404).json({ error: 'टिकट नहीं मिला' });
    return res.json({ message: 'उत्तर सफलतापूर्वक भेजा गया', ticket });
  } catch (err) {
    console.error('Reply ticket error:', err);
    return res.status(500).json({ error: 'उत्तर भेजने में विफलता' });
  }
});

// -------------------------------------------------------------
// 9. User Login & Security History Logs
// -------------------------------------------------------------
router.get('/auth-logs', async (req, res) => {
  try {
    const { userId, eventType, limit } = req.query as {
      userId?: string;
      eventType?: string;
      limit?: string;
    };

    const logs = await db.getAuthLogs({
      userId: userId ? String(userId).trim() : undefined,
      eventType: eventType ? String(eventType).trim() : undefined,
      limit: limit ? Number(limit) : 200
    });

    return res.json({ logs });
  } catch (err: any) {
    console.error('Get auth logs error:', err);
    return res.status(500).json({ error: err.message || 'लॉगिन इतिहास लोड करने में त्रुटि' });
  }
});

router.get('/users/:id/auth-history', async (req, res) => {
  try {
    const user = await db.getUserById(req.params.id);
    if (!user) return res.status(404).json({ error: 'उपयोगकर्ता नहीं मिला' });

    const logs = await db.getAuthLogs({ userId: user.id, limit: 100 });
    return res.json({
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        lastLoginAt: user.lastLoginAt,
        lastLogoutAt: user.lastLogoutAt
      },
      logs
    });
  } catch (err: any) {
    console.error('Get user auth history error:', err);
    return res.status(500).json({ error: err.message || 'उपयोगकर्ता इतिहास लोड करने में त्रुटि' });
  }
});

export default router;
