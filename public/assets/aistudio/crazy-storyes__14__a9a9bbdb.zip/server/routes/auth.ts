import express from 'express';
import { db } from '../db.js';
import { generateToken, verifyToken, hashPassword, comparePassword, authenticateToken, AuthRequest } from '../auth.js';
import { User, UserAuthLog } from '../types.js';

const router = express.Router();

export function getClientInfo(req: express.Request) {
  const forwarded = req.headers['x-forwarded-for'];
  const ip = typeof forwarded === 'string' ? forwarded.split(',')[0].trim() : req.socket.remoteAddress || req.ip || 'unknown';
  const userAgent = req.headers['user-agent'] || 'unknown';

  let deviceInfo = 'Desktop Browser';
  if (/mobile/i.test(userAgent)) deviceInfo = 'Mobile Browser';
  if (/android/i.test(userAgent)) deviceInfo = 'Android Device';
  if (/iphone|ipad|ipod/i.test(userAgent)) deviceInfo = 'iOS Device';

  return { ip, userAgent, deviceInfo };
}

// Check Admin configuration status
router.get('/admin-status', async (req, res) => {
  try {
    const users = await db.getUsers();
    const adminUser = users.find(u => u.role === 'admin');
    const settings = await db.getSettings();

    return res.json({
      hasAdmin: Boolean(adminUser),
      authorizedAdminEmail: adminUser?.email || settings.adminEmail || ''
    });
  } catch (err) {
    console.error('admin-status error:', err);
    return res.status(500).json({ error: 'एडमिन स्थिति जांच में त्रुटि' });
  }
});

// First-time Admin Account Setup (Owner Setup)
router.post('/admin-setup', async (req, res) => {
  try {
    const { email, password, name } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();

    if (!cleanEmail || !password) {
      return res.status(400).json({ error: 'ईमेल और पासवर्ड आवश्यक हैं (Email and password are required)' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए (Password must be at least 6 characters)' });
    }

    const users = await db.getUsers();
    const existingAdmin = users.find(u => u.role === 'admin');
    const settings = await db.getSettings();
    const isOwnerEmail =
      cleanEmail === 'divinecult2007@gmail.com' ||
      cleanEmail === 'ganish9784@gmail.com' ||
      cleanEmail === (settings.adminEmail || '').toLowerCase();

    if (existingAdmin && existingAdmin.email.toLowerCase() !== cleanEmail && !isOwnerEmail) {
      return res.status(400).json({
        error: `एडमिन खाता पहले ही सेटअप हो चुका है (${existingAdmin.email})। कृपया एडमिन लॉगिन का उपयोग करें।`
      });
    }

    // Save/update settings with this admin email in Supabase
    await db.updateSettings({ adminEmail: cleanEmail });

    // Check if user already exists, upgrade or create new admin
    const existingUser = await db.getUserByEmail(cleanEmail);
    const passwordHash = await hashPassword(password);

    if (existingUser) {
      existingUser.role = 'admin';
      existingUser.passwordHash = passwordHash;
      if (name) existingUser.name = name.trim();
      existingUser.membership = { isActive: true, planName: 'Owner VIP' };
      const updated = await db.updateUser(existingUser.id, existingUser);
      const targetUser = updated || existingUser;
      const token = generateToken(targetUser);
      return res.json({
        message: 'एडमिन खाता सफलतापूर्वक सेटअप हुआ! (Admin account setup successful)',
        token,
        user: {
          id: targetUser.id,
          name: targetUser.name,
          email: targetUser.email,
          role: targetUser.role,
          membership: targetUser.membership
        }
      });
    }

    const newAdmin: User = {
      id: `admin_${Date.now()}`,
      name: name?.trim() || 'Website Owner',
      email: cleanEmail,
      passwordHash,
      role: 'admin',
      isBlocked: false,
      membership: {
        isActive: true,
        planName: 'Owner VIP'
      },
      bookmarks: [],
      readingHistory: [],
      createdAt: new Date().toISOString()
    };

    const createdAdmin = await db.addUser(newAdmin);
    const token = generateToken(createdAdmin);

    return res.status(201).json({
      message: 'एडमिन खाता सफलतापूर्वक बनाया गया (Admin account created successfully)',
      token,
      user: {
        id: createdAdmin.id,
        name: createdAdmin.name,
        email: createdAdmin.email,
        role: createdAdmin.role,
        membership: createdAdmin.membership
      }
    });
  } catch (err) {
    console.error('Admin setup error:', err);
    return res.status(500).json({ error: 'एडमिन सेटअप में त्रुटि (Internal server error)' });
  }
});

// Admin Login
router.post('/admin-login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const cleanEmail = (email || '').trim().toLowerCase();
    const client = getClientInfo(req);

    if (!cleanEmail || !password) {
      await db.addAuthLog({
        email: cleanEmail,
        eventType: 'failed_login',
        ipAddress: client.ip,
        userAgent: client.userAgent,
        deviceInfo: client.deviceInfo,
        status: 'failed',
        failureReason: 'ईमेल या पासवर्ड अनुपलब्ध (Missing email or password)'
      });
      return res.status(400).json({ error: 'ईमेल और पासवर्ड आवश्यक हैं (Email and password are required)' });
    }

    const user = await db.getUserByEmail(cleanEmail);
    if (!user || user.role !== 'admin') {
      await db.addAuthLog({
        userId: user?.id,
        email: cleanEmail,
        eventType: 'failed_login',
        ipAddress: client.ip,
        userAgent: client.userAgent,
        deviceInfo: client.deviceInfo,
        status: 'failed',
        failureReason: !user ? 'खाता मौजूद नहीं है' : 'अनधिकृत गैर-व्यवस्थापक रोल'
      });
      return res.status(401).json({
        error: 'एडमिन क्रेडेंशियल्स अमान्य हैं या यह खाता एडमिन के रूप में पंजीकृत नहीं है। (Invalid admin credentials or setup needed)'
      });
    }

    const isMatch = await comparePassword(password, user.passwordHash);
    if (!isMatch) {
      await db.addAuthLog({
        userId: user.id,
        email: cleanEmail,
        eventType: 'failed_login',
        ipAddress: client.ip,
        userAgent: client.userAgent,
        deviceInfo: client.deviceInfo,
        status: 'failed',
        failureReason: 'गलत पासवर्ड (Incorrect password)'
      });
      return res.status(401).json({ error: 'गलत पासवर्ड (Incorrect password)' });
    }

    const now = new Date().toISOString();
    await db.updateUser(user.id, { lastLoginAt: now });
    user.lastLoginAt = now;

    await db.addAuthLog({
      userId: user.id,
      email: user.email,
      eventType: 'login',
      ipAddress: client.ip,
      userAgent: client.userAgent,
      deviceInfo: client.deviceInfo,
      status: 'success'
    });

    const token = generateToken(user);
    return res.json({
      message: 'एडमिन लॉगिन सफल (Admin login successful)',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        membership: user.membership,
        lastLoginAt: user.lastLoginAt,
        lastLogoutAt: user.lastLogoutAt
      }
    });
  } catch (err) {
    console.error('Admin login error:', err);
    return res.status(500).json({ error: 'लॉगिन में त्रुटि (Internal server error)' });
  }
});

// Regular Reader Registration (ALWAYS assigns role: 'reader')
router.post('/register', async (req, res) => {
  try {
    const { name, email, password } = req.body;
    const client = getClientInfo(req);

    if (!name || !email || !password) {
      return res.status(400).json({ error: 'नाम, ईमेल और पासवर्ड आवश्यक हैं (Name, email and password required)' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'पासवर्ड कम से कम 6 अक्षरों का होना चाहिए (Password must be at least 6 characters)' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const existing = await db.getUserByEmail(cleanEmail);
    if (existing) {
      return res.status(400).json({ error: 'यह ईमेल पहले से पंजीकृत है (Email already registered)' });
    }

    const now = new Date().toISOString();
    const passwordHash = await hashPassword(password);
    const newUser: User = {
      id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: name.trim(),
      email: cleanEmail,
      passwordHash,
      role: 'reader', // Strictly forced reader role
      isBlocked: false,
      membership: {
        isActive: false
      },
      bookmarks: [],
      readingHistory: [],
      lastLoginAt: now,
      createdAt: now
    };

    const savedUser = await db.addUser(newUser);

    // Record registration audit log
    await db.addAuthLog({
      userId: savedUser.id,
      email: savedUser.email,
      eventType: 'registration',
      ipAddress: client.ip,
      userAgent: client.userAgent,
      deviceInfo: client.deviceInfo,
      status: 'success'
    });

    // Record immediate initial login audit log
    await db.addAuthLog({
      userId: savedUser.id,
      email: savedUser.email,
      eventType: 'login',
      ipAddress: client.ip,
      userAgent: client.userAgent,
      deviceInfo: client.deviceInfo,
      status: 'success'
    });

    const token = generateToken(savedUser);

    return res.status(201).json({
      message: 'पंजीकरण सफल (Registration successful)',
      token,
      user: {
        id: savedUser.id,
        name: savedUser.name,
        email: savedUser.email,
        role: savedUser.role,
        membership: savedUser.membership,
        bookmarks: savedUser.bookmarks,
        lastLoginAt: savedUser.lastLoginAt,
        lastLogoutAt: savedUser.lastLogoutAt
      }
    });
  } catch (err) {
    console.error('Register error:', err);
    return res.status(500).json({ error: 'पंजीकरण में त्रुटि (Internal server error)' });
  }
});

// Reader / General Login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    const client = getClientInfo(req);
    const cleanEmail = (email || '').trim().toLowerCase();

    if (!cleanEmail || !password) {
      await db.addAuthLog({
        email: cleanEmail,
        eventType: 'failed_login',
        ipAddress: client.ip,
        userAgent: client.userAgent,
        deviceInfo: client.deviceInfo,
        status: 'failed',
        failureReason: 'ईमेल या पासवर्ड अनुपलब्ध (Missing email or password)'
      });
      return res.status(400).json({ error: 'ईमेल और पासवर्ड आवश्यक हैं (Email and password required)' });
    }

    const user = await db.getUserByEmail(cleanEmail);
    if (!user) {
      await db.addAuthLog({
        email: cleanEmail,
        eventType: 'failed_login',
        ipAddress: client.ip,
        userAgent: client.userAgent,
        deviceInfo: client.deviceInfo,
        status: 'failed',
        failureReason: 'उपयोगकर्ता पंजीकृत नहीं है (User not found)'
      });
      return res.status(401).json({ error: 'ईमेल या पासवर्ड गलत है (Invalid email or password)' });
    }

    if (user.isBlocked) {
      await db.addAuthLog({
        userId: user.id,
        email: user.email,
        eventType: 'failed_login',
        ipAddress: client.ip,
        userAgent: client.userAgent,
        deviceInfo: client.deviceInfo,
        status: 'failed',
        failureReason: 'खाता अवरुद्ध है (Account blocked)'
      });
      return res.status(403).json({ error: 'यह खाता अवरुद्ध है (Account blocked)' });
    }

    const isMatch = await comparePassword(password, user.passwordHash);
    if (!isMatch) {
      await db.addAuthLog({
        userId: user.id,
        email: user.email,
        eventType: 'failed_login',
        ipAddress: client.ip,
        userAgent: client.userAgent,
        deviceInfo: client.deviceInfo,
        status: 'failed',
        failureReason: 'गलत पासवर्ड (Incorrect password)'
      });
      return res.status(401).json({ error: 'ईमेल या पासवर्ड गलत है (Invalid email or password)' });
    }

    const now = new Date().toISOString();
    await db.updateUser(user.id, { lastLoginAt: now });
    user.lastLoginAt = now;

    await db.addAuthLog({
      userId: user.id,
      email: user.email,
      eventType: 'login',
      ipAddress: client.ip,
      userAgent: client.userAgent,
      deviceInfo: client.deviceInfo,
      status: 'success'
    });

    const token = generateToken(user);
    return res.json({
      message: 'लॉगिन सफल (Login successful)',
      token,
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        membership: user.membership,
        bookmarks: user.bookmarks,
        readingHistory: user.readingHistory,
        lastLoginAt: user.lastLoginAt,
        lastLogoutAt: user.lastLogoutAt
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    return res.status(500).json({ error: 'लॉगिन में त्रुटि (Internal server error)' });
  }
});

// Logout and Invalidate Active Token Session
router.post('/logout', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1];
    const client = getClientInfo(req);
    const now = new Date().toISOString();

    if (token && req.user) {
      const decoded = verifyToken(token);
      const expiresAt = decoded && (decoded as any).exp
        ? new Date((decoded as any).exp * 1000).toISOString()
        : new Date(Date.now() + 30 * 86400000).toISOString();

      await db.revokeToken(token, req.user.id, expiresAt, 'User logged out');
      await db.updateUser(req.user.id, { lastLogoutAt: now });

      await db.addAuthLog({
        userId: req.user.id,
        email: req.user.email,
        eventType: 'logout',
        ipAddress: client.ip,
        userAgent: client.userAgent,
        deviceInfo: client.deviceInfo,
        status: 'success'
      });
    }

    return res.json({
      success: true,
      message: 'सफलतापूर्वक लॉगआउट किया गया (Logged out successfully)'
    });
  } catch (err: any) {
    console.error('Logout error:', err);
    return res.status(500).json({ error: 'लॉगआउट में त्रुटि' });
  }
});

// User's Own Login / Logout / Session History (Strictly Isolated)
router.get('/my-history', authenticateToken, async (req: AuthRequest, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'लॉगिन आवश्यक है' });
    const logs = await db.getAuthLogs({ userId: req.user.id, limit: 50 });
    const freshUser = await db.getUserById(req.user.id);

    return res.json({
      logs,
      lastLoginAt: freshUser?.lastLoginAt || req.user.lastLoginAt,
      lastLogoutAt: freshUser?.lastLogoutAt || req.user.lastLogoutAt
    });
  } catch (err: any) {
    console.error('my-history error:', err);
    return res.status(500).json({ error: 'लॉगिन इतिहास लोड करने में त्रुटि' });
  }
});

// Current User Profile
router.get('/me', authenticateToken, async (req: AuthRequest, res) => {
  if (!req.user) return res.status(401).json({ error: 'उपयोगकर्ता नहीं मिला' });
  const freshUser = await db.getUserById(req.user.id);
  const user = freshUser || req.user;
  const { passwordHash, ...safeUser } = user;
  return res.json({ user: safeUser });
});

// Toggle Bookmark
router.post('/bookmarks/:novelId', authenticateToken, async (req: AuthRequest, res) => {
  if (!req.user) return res.status(401).json({ error: 'लॉगिन आवश्यक है' });
  const novelId = req.params.novelId;
  const bookmarks = req.user.bookmarks || [];
  const exists = bookmarks.includes(novelId);
  const updatedBookmarks = exists ? bookmarks.filter(id => id !== novelId) : [...bookmarks, novelId];

  await db.updateUser(req.user.id, { bookmarks: updatedBookmarks });
  return res.json({ bookmarks: updatedBookmarks, isBookmarked: !exists });
});

// Save Reading Progress
router.post('/reading-progress', authenticateToken, async (req: AuthRequest, res) => {
  if (!req.user) return res.status(401).json({ error: 'लॉगिन आवश्यक है' });
  const { novelId, chapterId, chapterNumber, novelTitle, chapterTitle, progressPercent, mode } = req.body;

  if (!novelId || !chapterId) {
    return res.status(400).json({ error: 'novelId और chapterId आवश्यक हैं' });
  }

  const history = req.user.readingHistory || [];
  const filtered = history.filter(h => h.novelId !== novelId);
  filtered.unshift({
    novelId,
    chapterId,
    chapterNumber: Number(chapterNumber) || 1,
    novelTitle: novelTitle || '',
    chapterTitle: chapterTitle || '',
    progressPercent: Math.min(100, Math.max(0, Number(progressPercent) || 0)),
    mode: mode === 'audio' ? 'audio' : 'text',
    updatedAt: new Date().toISOString()
  });

  const slicedHistory = filtered.slice(0, 5); // keep last 5 unique novels
  await db.updateUser(req.user.id, { readingHistory: slicedHistory });
  return res.json({ success: true, readingHistory: slicedHistory });
});

// Clear Reading History
router.delete('/reading-history', authenticateToken, async (req: AuthRequest, res) => {
  if (!req.user) return res.status(401).json({ error: 'लॉगिन आवश्यक है' });
  await db.updateUser(req.user.id, { readingHistory: [] });
  return res.json({ success: true, readingHistory: [] });
});

export default router;
