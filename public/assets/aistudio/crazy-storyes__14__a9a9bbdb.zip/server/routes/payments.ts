import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { db, PRIVATE_SCREENSHOTS_DIR } from '../db.js';
import { authenticateToken, AuthRequest } from '../auth.js';
import { PaymentRequest } from '../types.js';

const router = express.Router();

const screenshotStorage = multer.diskStorage({
  destination: (_req, _file, cb) => {
    cb(null, PRIVATE_SCREENSHOTS_DIR);
  },
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase() || '.png';
    cb(null, `pay_${Date.now()}_${Math.random().toString(36).substring(2, 8)}${ext}`);
  }
});

const uploadScreenshot = multer({
  storage: screenshotStorage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (allowed.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error('केवल JPG, JPEG, PNG या WEBP स्क्रीनशॉट ही अपलोड करें'));
    }
  }
});

// Get UPI Payment Configuration (Public)
router.get('/config', async (req, res) => {
  try {
    const [settings, allPlans] = await Promise.all([
      db.getSettings(),
      db.getPlans()
    ]);
    const plans = allPlans.filter(p => p.isActive);

    return res.json({
      upiId: settings.upiId || 'crazystoryes@upi',
      upiQrCodeUrl: settings.upiQrCodeUrl || '',
      websiteName: settings.websiteName,
      adminEmail: settings.adminEmail,
      supportEmail: settings.supportEmail || 'divinecult2007@gmail.com',
      supportPhone: settings.supportPhone || '+91 8290188433',
      plans
    });
  } catch (err) {
    console.error('Payment config error:', err);
    return res.status(500).json({ error: 'कॉन्फ़िगरेशन लोड करने में त्रुटि' });
  }
});

// Submit Manual UPI Payment Request (Logged-in Reader)
router.post('/create', authenticateToken, (req: AuthRequest, res) => {
  uploadScreenshot.single('screenshot')(req, res, async (uploadErr) => {
    if (uploadErr) {
      return res.status(400).json({ error: uploadErr.message || 'स्क्रीनशॉट अपलोड में त्रुटि' });
    }
    try {
      const user = req.user;
      if (!user) return res.status(401).json({ error: 'लॉगिन आवश्यक है' });

      const { fullName, itemType, itemId, itemName, amount, utrNumber } = req.body;

      if (!fullName || !fullName.trim()) {
        return res.status(400).json({ error: 'कृपया अपना पूरा नाम दर्ज करें (Full Name is required)' });
      }

      if (!amount || Number(amount) <= 0) {
        return res.status(400).json({ error: 'अमान्य भुगतान राशि (Invalid amount)' });
      }

      if (!itemType || !itemId || !itemName) {
        return res.status(400).json({ error: 'प्लान या उपन्यास का चयन आवश्यक है (Item details required)' });
      }

      if (!req.file) {
        return res.status(400).json({ error: 'कृपया भुगतान का स्क्रीनशॉट अपलोड करें (Payment screenshot is required)' });
      }

      const newPayment: PaymentRequest = {
        id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        userId: user.id,
        userName: fullName.trim(),
        userEmail: user.email,
        itemType: itemType === 'novel' ? 'novel' : 'membership',
        itemId,
        itemName,
        amount: Number(amount),
        utrNumber: utrNumber ? utrNumber.trim() : undefined,
        screenshotPath: req.file.filename,
        status: 'pending',
        createdAt: new Date().toISOString()
      };

      const savedPayment = await db.addPayment(newPayment);

      return res.status(201).json({
        message: 'भुगतान अनुरोध सफलतापूर्वक दर्ज किया गया! एडमिन द्वारा सत्यापन के बाद आपकी वीआईपी सदस्यता सक्रिय हो जाएगी। (Payment request submitted successfully)',
        payment: savedPayment
      });
    } catch (err) {
      console.error('Payment request error:', err);
      return res.status(500).json({ error: 'भुगतान अनुरोध दर्ज करने में त्रुटि' });
    }
  });
});

// Get User's Own Payment History
router.get('/my-history', authenticateToken, async (req: AuthRequest, res) => {
  try {
    if (!req.user) return res.status(401).json({ error: 'लॉगिन आवश्यक है' });
    const allPayments = await db.getPayments();
    const userPayments = allPayments.filter(p => p.userId === req.user!.id);
    return res.json({ payments: userPayments });
  } catch (err) {
    console.error('Payment history error:', err);
    return res.status(500).json({ error: 'भुगतान इतिहास लोड करने में त्रुटि' });
  }
});

export default router;
