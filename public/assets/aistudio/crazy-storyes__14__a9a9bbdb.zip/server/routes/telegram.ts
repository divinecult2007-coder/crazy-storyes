import { Router } from 'express';
import crypto from 'crypto';
import { db } from '../db.js';
import { telegramService } from '../telegram.js';
import { AuthRequest, authenticateToken, optionalAuth, requireAdmin } from '../auth.js';
import type { Novel, User, Chapter } from '../types.js';

const router = Router();

// Helper to check if a user currently has active VIP membership
function userHasActiveVip(user: User): boolean {
  if (user.role === 'admin') return true;
  if (!user.membership?.isActive) return false;
  if (!user.membership.expiresAt) return true; // Lifetime
  return new Date(user.membership.expiresAt).getTime() > Date.now();
}

// ==========================================
// 1. TELEGRAM WEBHOOK ENDPOINT
// ==========================================
router.post('/webhook', async (req, res) => {
  // 1. Enforce Webhook Secret Authentication
  const configuredSecret = process.env.TELEGRAM_WEBHOOK_SECRET?.trim();
  const secretHeader = req.headers['x-telegram-bot-api-secret-token'];

  // Requirement: Production must refuse to process webhook updates if secret is missing or mismatched
  if (!configuredSecret) {
    console.warn('[Telegram Webhook] Rejected: TELEGRAM_WEBHOOK_SECRET is not configured on server');
    return res.status(403).json({
      ok: false,
      error: 'TELEGRAM_WEBHOOK_SECRET is not configured on server. Webhook requests rejected for security.'
    });
  }

  if (!secretHeader || secretHeader !== configuredSecret) {
    console.warn('[Telegram Webhook] Unauthorized request rejected: invalid or missing x-telegram-bot-api-secret-token');
    return res.status(403).json({ ok: false, error: 'Unauthorized webhook request' });
  }

  const update = req.body;
  if (!update || typeof update !== 'object') {
    return res.status(200).json({ ok: true });
  }

  // 2. Duplicate Update Protection
  const updateId = Number(update.update_id);
  if (updateId) {
    const alreadyProcessed = await db.isTelegramUpdateProcessed(updateId);
    if (alreadyProcessed) {
      console.log(`[Telegram Webhook] Skipping duplicate update_id: ${updateId}`);
      return res.status(200).json({ ok: true, duplicate: true });
    }
  }

  try {
    if (update.message) {
      const msg = update.message;
      const chatId = msg.chat?.id;
      const text = (msg.text || '').trim();
      const from = msg.from;

      if (!chatId || !from) {
        if (updateId) await db.markTelegramUpdateProcessed(updateId);
        return res.status(200).json({ ok: true });
      }

      // Handle /start command, optionally with linking code
      if (text.startsWith('/start')) {
        const parts = text.split(/\s+/);
        const code = parts[1]?.trim();

        if (code) {
          // Attempt account link
          const linkRecord = await db.getTelegramLinkCode(code);
          if (!linkRecord) {
            await telegramService.sendMessage(
              chatId,
              `⚠️ <b>लिंकिंग कोड अमान्य है</b>\n\n` +
              `यह कोड सिस्टम में मौजूद नहीं है या पहले ही उपयोग किया जा चुका है।\n` +
              `कृपया Crazy Storyes वेबसाइट पर जाकर नया कोड जनरेट करें।`
            );
            if (updateId) await db.markTelegramUpdateProcessed(updateId);
            return res.status(200).json({ ok: true });
          }

          if (linkRecord.usedAt) {
            await telegramService.sendMessage(
              chatId,
              `⚠️ <b>कोड पहले ही उपयोग हो चुका है</b>\n\n` +
              `कृपया Crazy Storyes वेबसाइट पर नया लिंकिंग कोड जनरेट करें।`
            );
            if (updateId) await db.markTelegramUpdateProcessed(updateId);
            return res.status(200).json({ ok: true });
          }

          if (new Date(linkRecord.expiresAt).getTime() < Date.now()) {
            await telegramService.sendMessage(
              chatId,
              `⌛ <b>लिंकिंग कोड की समय-सीमा समाप्त हो गई है</b>\n\n` +
              `यह कोड 15 मिनट के लिए वैध था। कृपया वेबसाइट पर नया कोड जनरेट करें।`
            );
            if (updateId) await db.markTelegramUpdateProcessed(updateId);
            return res.status(200).json({ ok: true });
          }

          // Link account
          const targetUser = await db.getUserById(linkRecord.userId);
          if (!targetUser) {
            await telegramService.sendMessage(chatId, `⚠️ उपयोगकर्ता खाता नहीं मिला।`);
            if (updateId) await db.markTelegramUpdateProcessed(updateId);
            return res.status(200).json({ ok: true });
          }

          await db.linkUserTelegram(targetUser.id, {
            telegramUserId: from.id,
            telegramUsername: from.username,
            telegramFirstName: from.first_name,
          });

          await db.markTelegramLinkCodeUsed(linkRecord.id);
          console.log(`[Telegram Webhook] Account linked successfully: User ID ${targetUser.id} -> TG User ID ${from.id}`);

          const isVip = userHasActiveVip(targetUser);
          const vipStatusText = isVip
            ? `👑 <b>VIP स्टेटस:</b> एक्टिव (वैधता: ${targetUser.membership?.expiresAt ? new Date(targetUser.membership.expiresAt).toLocaleDateString('hi-IN') : 'सक्रिय'})`
            : `🆓 <b>सदस्यता:</b> सामान्य सदस्य`;

          await telegramService.sendMessage(
            chatId,
            `🎉 <b>बधाई हो! आपका Telegram खाता Crazy Storyes से सफलतापूर्वक लिंक हो गया है!</b>\n\n` +
            `👤 <b>यूज़र:</b> ${targetUser.name}\n` +
            `📱 <b>Telegram ID:</b> ${from.id}\n` +
            `${vipStatusText}\n\n` +
            `🚀 अब आप वेबसाइट पर जाकर किसी भी उपन्यास के 'Listen on Telegram' बटन पर क्लिक करके सीधे चैनल से जुड़ सकते हैं!\n\n` +
            `<i>क्रेज़ी स्टोरीज़ परिवार में आपका स्वागत है!</i>`
          );

          if (updateId) await db.markTelegramUpdateProcessed(updateId);
          return res.status(200).json({ ok: true });
        }

        // Generic /start without code
        const existingUser = await db.getUserByTelegramId(from.id);
        if (existingUser) {
          const isVip = userHasActiveVip(existingUser);
          const vipText = isVip ? '👑 VIP सक्रिय' : '🆓 सामान्य पाठक';
          await telegramService.sendMessage(
            chatId,
            `नमस्ते <b>${from.first_name || 'दोस्त'}</b>! 👋\n\n` +
            `आपका खाता पहले से Crazy Storyes से जुड़ा हुआ है:\n` +
            `📧 ईमेल: ${existingUser.email}\n` +
            `⭐ स्थिति: ${vipText}\n\n` +
            `ऑडियो उपन्यास सुनने के लिए वेबसाइट पर जाएँ और अपनी पसंद के उपन्यास का Telegram चैनल जॉइन करें!`
          );
        } else {
          await telegramService.sendMessage(
            chatId,
            `👋 <b>नमस्ते! Crazy Storyes Manager Bot में आपका स्वागत है।</b>\n\n` +
            `यह बॉट आपको आधिकारिक Crazy Storyes ऑडियो उपन्यासों के Telegram चैनल्स से जोड़ता है।\n\n` +
            `🔗 <b>खाता कैसे लिंक करें?</b>\n` +
            `1. Crazy Storyes वेबसाइट खोलें।\n` +
            `2. किसी भी उपन्यास पर 'Listen on Telegram' पर क्लिक करें।\n` +
            `3. दिए गए लिंक पर टैप करें, आपका खाता तुरंत लिंक हो जाएगा!\n\n` +
            `मदद के लिए /help टाइप करें।`
          );
        }

        if (updateId) await db.markTelegramUpdateProcessed(updateId);
        return res.status(200).json({ ok: true });
      }

      // /status command
      if (text === '/status') {
        const user = await db.getUserByTelegramId(from.id);
        if (!user) {
          await telegramService.sendMessage(
            chatId,
            `ℹ️ <b>आपका Telegram खाता अभी किसी Crazy Storyes खाते से लिंक नहीं है।</b>\n\n` +
            `कृपया वेबसाइट पर जाकर 'Connect Telegram' बटन पर क्लिक करें।`
          );
          if (updateId) await db.markTelegramUpdateProcessed(updateId);
          return res.status(200).json({ ok: true });
        }

        const isVip = userHasActiveVip(user);
        const expiryDate = user.membership?.expiresAt ? new Date(user.membership.expiresAt).toLocaleDateString('hi-IN') : 'N/A';

        await telegramService.sendMessage(
          chatId,
          `📊 <b>खाता स्थिति (Account Status):</b>\n\n` +
          `👤 <b>नाम:</b> ${user.name}\n` +
          `📧 <b>ईमेल:</b> ${user.email}\n` +
          `👑 <b>VIP सदस्यता:</b> ${isVip ? `सक्रिय (वैधता: ${expiryDate})` : 'निष्क्रिय / समाप्त'}\n` +
          `🔗 <b>लिंक्ड समय:</b> ${user.telegram?.linkedAt ? new Date(user.telegram.linkedAt).toLocaleDateString('hi-IN') : 'हाल ही में'}\n\n` +
          `${isVip ? '✅ आप सभी VIP और फ्री चैनल्स जॉइन करने के पात्र हैं।' : 'ℹ️ VIP चैनल्स जॉइन करने के लिए वेबसाइट पर जाकर प्लान रिन्यू करें।'}`
        );
        if (updateId) await db.markTelegramUpdateProcessed(updateId);
        return res.status(200).json({ ok: true });
      }

      // /unlink command
      if (text === '/unlink') {
        const user = await db.getUserByTelegramId(from.id);
        if (!user) {
          await telegramService.sendMessage(chatId, `कोई लिंक्ड खाता नहीं मिला।`);
          if (updateId) await db.markTelegramUpdateProcessed(updateId);
          return res.status(200).json({ ok: true });
        }

        await db.unlinkUserTelegram(user.id);
        await telegramService.sendMessage(
          chatId,
          `✅ आपका Telegram खाता Crazy Storyes वेबसाइट से अनलिंक कर दिया गया है।`
        );
        if (updateId) await db.markTelegramUpdateProcessed(updateId);
        return res.status(200).json({ ok: true });
      }

      // /help command
      if (text === '/help') {
        await telegramService.sendMessage(
          chatId,
          `📖 <b>Crazy Storyes Bot कमांड सूची:</b>\n\n` +
          `/status - अपनी सदस्यता व खाते की स्थिति देखें\n` +
          `/unlink - Telegram खाते को अनलिंक करें\n` +
          `/help - सहायता जानकारी प्राप्त करें\n\n` +
          `🌐 वेबसाइट: Crazy Storyes Novel Platform`
        );
        if (updateId) await db.markTelegramUpdateProcessed(updateId);
        return res.status(200).json({ ok: true });
      }
    }

    // Default acknowledge for unhandled messages
    if (updateId) await db.markTelegramUpdateProcessed(updateId);
    if (!res.headersSent) {
      return res.status(200).json({ ok: true });
    }
  } catch (err: any) {
    console.error('Error handling Telegram webhook:', err);
    if (!res.headersSent) {
      return res.status(500).json({ ok: false, error: 'Webhook processing failed' });
    }
  }
});

// ==========================================
// 2. USER ENDPOINTS
// ==========================================

/**
 * Generate a single-use 15-minute linking code for the logged-in user
 */
router.post('/link-code', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const user = req.user!;
    const code = 'CS' + crypto.randomBytes(4).toString('hex').toUpperCase(); // e.g. CS9F3B2A10
    const expiresAt = new Date(Date.now() + 15 * 60 * 1000).toISOString(); // 15 mins

    await db.createTelegramLinkCode({
      id: `tlc_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      code,
      userId: user.id,
      userEmail: user.email,
      userName: user.name,
      expiresAt,
      createdAt: new Date().toISOString(),
    });

    const botUsername = telegramService.botUsername;
    const deepLink = `https://t.me/${botUsername}?start=${code}`;

    res.json({
      ok: true,
      code,
      botUsername,
      deepLink,
      expiresAt,
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Check linking status of current user
 */
router.get('/status', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const user = req.user!;
    const isVip = userHasActiveVip(user);
    const accesses = await db.getUserTelegramAccesses(user.id);

    res.json({
      ok: true,
      linked: Boolean(user.telegram?.telegramUserId),
      telegram: user.telegram || null,
      isVip,
      vipExpiresAt: user.membership?.expiresAt || null,
      accesses,
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Unlink telegram account
 */
router.post('/unlink', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const user = req.user!;
    await db.unlinkUserTelegram(user.id);
    res.json({ ok: true, message: 'Telegram खाता सफलतापूर्वक अनलिंक कर दिया गया' });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Access a novel's Telegram channel:
 * - Supports Public Channel (direct open)
 * - Supports Private Channel (validates permissions & generates single-use 10-minute invite link)
 */
router.post('/novels/:novelId/join', authenticateToken, async (req: AuthRequest, res) => {
  try {
    const user = req.user!;
    const { novelId } = req.params;

    const novel = await db.getNovelById(novelId);
    if (!novel) {
      return res.status(404).json({ ok: false, error: 'उपन्यास नहीं मिला' });
    }

    if (!novel.telegramIntegrationEnabled || (!novel.telegramChannelLink && !novel.telegramChannelId)) {
      return res.status(400).json({
        ok: false,
        error: 'Telegram Group Not Configured (इस उपन्यास के लिए Telegram ग्रुप अभी कॉन्फ़िगर नहीं है)',
        code: 'TELEGRAM_GROUP_NOT_CONFIGURED',
      });
    }

    const isChannelVip = novel.telegramAccessType === 'premium' || novel.isPremium;
    const isVip = userHasActiveVip(user);

    // 1. Check VIP requirement
    if (isChannelVip && !isVip) {
      return res.status(403).json({
        ok: false,
        error: 'यह एक VIP ऑडियो उपन्यास चैनल है। जॉइन करने के लिए सक्रिय VIP सदस्यता आवश्यक है।',
        code: 'VIP_REQUIRED',
      });
    }

    // 2. CASE A: PUBLIC CHANNEL
    const isPublic = novel.telegramChannelPrivacy === 'public' || (!novel.telegramChannelId && Boolean(novel.telegramChannelLink));
    if (isPublic && novel.telegramChannelLink) {
      let publicLink = novel.telegramChannelLink.trim();
      if (!publicLink.startsWith('http://') && !publicLink.startsWith('https://')) {
        publicLink = publicLink.startsWith('@') ? `https://t.me/${publicLink.slice(1)}` : `https://t.me/${publicLink}`;
      }

      await db.addTelegramLog({
        id: `tlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        userId: user.id,
        telegramUserId: user.telegram?.telegramUserId,
        channelId: novel.telegramChannelLink,
        novelId: novel.id,
        action: 'link_generated',
        status: 'success',
        details: `Public channel accessed: ${publicLink}`,
        createdAt: new Date().toISOString(),
      });

      return res.json({
        ok: true,
        channelType: 'public',
        channelLink: publicLink,
        channelName: novel.telegramChannelName || novel.title,
        accessType: isChannelVip ? 'premium' : 'free',
      });
    }

    // 3. CASE B: PRIVATE CHANNEL / GROUP
    if (!novel.telegramChannelId) {
      return res.status(400).json({
        ok: false,
        error: 'Telegram Group Not Configured (इस उपन्यास के लिए Telegram Chat ID कॉन्फ़िगर नहीं है)',
        code: 'TELEGRAM_GROUP_NOT_CONFIGURED',
      });
    }

    // Validate that numeric Chat ID was used, NOT an invite URL
    const { isTelegramInviteUrl } = await import('../telegram.js');
    if (isTelegramInviteUrl(novel.telegramChannelId)) {
      return res.status(400).json({
        ok: false,
        error: 'अमान्य कॉन्फ़िगरेशन: इनवाइट लिंक (URL) को संख्यात्मक Chat ID के रूप में उपयोग नहीं किया जा सकता। कृपया संख्यात्मक ID (-100...) दर्ज करें।',
        code: 'INVALID_CHAT_ID',
      });
    }

    // For private channels, user must link their Telegram account so the bot can authorize and manage access
    if (!user.telegram?.telegramUserId) {
      return res.status(400).json({
        ok: false,
        error: 'प्राइवेट चैनल जॉइन करने से पहले कृपया अपना Telegram खाता लिंक करें',
        code: 'TELEGRAM_NOT_LINKED',
      });
    }

    // Generate single-use invite link with 10-minute validity and 1-member limit
    const inviteRes = await telegramService.createSingleUseInviteLink(
      novel.telegramChannelId,
      `CrazyStoryes - ${user.name || user.email} (${novel.title})`,
      10 // 10 minutes
    );

    if (!inviteRes.ok || !inviteRes.inviteLink) {
      return res.status(500).json({
        ok: false,
        error: inviteRes.description || 'Failed to generate Telegram invite link. Check bot permissions.',
        code: 'BOT_ERROR',
      });
    }

    const accessType: 'free' | 'premium' = isChannelVip ? 'premium' : 'free';
    const nowIso = new Date().toISOString();

    // Save or update access record
    await db.saveTelegramAccess({
      id: `tacc_${user.id}_${novel.id}`,
      userId: user.id,
      telegramUserId: user.telegram.telegramUserId,
      novelId: novel.id,
      novelTitle: novel.title,
      channelId: novel.telegramChannelId,
      channelName: novel.telegramChannelName || novel.title,
      accessType,
      inviteLink: inviteRes.inviteLink,
      status: 'active',
      joinedAt: nowIso,
      expiresAt: inviteRes.expireDate ? new Date(inviteRes.expireDate).toISOString() : undefined,
      createdAt: nowIso,
      updatedAt: nowIso,
    });

    await db.addTelegramLog({
      id: `tlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: user.id,
      telegramUserId: user.telegram.telegramUserId,
      channelId: novel.telegramChannelId,
      novelId: novel.id,
      action: 'link_generated',
      status: 'success',
      details: `Single-use 10-minute invite link generated for ${accessType} novel`,
      createdAt: nowIso,
    });

    return res.json({
      ok: true,
      channelType: 'private',
      inviteLink: inviteRes.inviteLink,
      expiresAt: inviteRes.expireDate,
      channelName: novel.telegramChannelName || novel.title,
      accessType,
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Access a chapter's dedicated Telegram Audio link
 * - Free chapters: accessible to any user or guest
 * - VIP/Premium chapters: requires active VIP membership
 * - Returns direct Telegram deep link / web link
 */
const handleChapterAudioAccess = async (req: AuthRequest, res: any) => {
  try {
    const { chapterId } = req.params;
    const chapter = await db.getChapterById(chapterId);
    if (!chapter) {
      return res.status(404).json({ ok: false, error: 'अध्याय नहीं मिला (Chapter not found)' });
    }

    if (!chapter.isPublished && req.user?.role !== 'admin') {
      return res.status(404).json({ ok: false, error: 'अध्याय अभी प्रकाशित नहीं हुआ है' });
    }

    const rawLink = chapter.telegramMessageLink?.trim();
    if (!rawLink) {
      return res.status(404).json({
        ok: false,
        code: 'AUDIO_NOT_CONFIGURED',
        error: 'Telegram Audio Not Configured (इस अध्याय के लिए Telegram ऑडियो लिंक अभी सेट नहीं किया गया है)'
      });
    }

    const isPremiumChapter = Boolean(chapter.isPremium || chapter.telegramAudioAccessType === 'premium');

    // For premium chapter audio, check user authorization
    if (isPremiumChapter) {
      if (!req.user) {
        return res.status(401).json({
          ok: false,
          code: 'LOGIN_REQUIRED',
          error: 'यह एक VIP अध्याय है। Telegram ऑडियो सुनने के लिए कृपया पहले लॉगिन करें।'
        });
      }

      const freshUser = (await db.getUserById(req.user.id)) || req.user;
      const isVip = userHasActiveVip(freshUser);

      if (!isVip) {
        return res.status(403).json({
          ok: false,
          code: 'VIP_REQUIRED',
          error: 'इस VIP अध्याय का Telegram ऑडियो सुनने के लिए सक्रिय VIP सदस्यता आवश्यक है।'
        });
      }
    }

    // Format proper Telegram link
    let telegramLink = rawLink;
    if (!telegramLink.startsWith('http://') && !telegramLink.startsWith('https://')) {
      if (telegramLink.startsWith('t.me/')) {
        telegramLink = `https://${telegramLink}`;
      } else if (telegramLink.startsWith('@')) {
        telegramLink = `https://t.me/${telegramLink.slice(1)}`;
      } else {
        telegramLink = `https://t.me/${telegramLink}`;
      }
    }

    // Audit log
    await db.addTelegramLog({
      id: `tlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: req.user?.id || 'guest',
      telegramUserId: req.user?.telegram?.telegramUserId,
      channelId: chapter.telegramChatId || chapter.novelId,
      novelId: chapter.novelId,
      action: 'chapter_audio_accessed',
      status: 'success',
      details: `Chapter ${chapter.chapterNumber} Telegram audio opened: ${chapter.title} (${isPremiumChapter ? 'VIP' : 'FREE'})`,
      createdAt: new Date().toISOString(),
    });

    return res.json({
      ok: true,
      telegramMessageLink: telegramLink,
      telegramMessageId: chapter.telegramMessageId,
      telegramChatId: chapter.telegramChatId,
      telegramDestinationType: chapter.telegramDestinationType || 'channel',
      telegramAudioAccessType: isPremiumChapter ? 'premium' : 'free',
      chapterNumber: chapter.chapterNumber,
      title: chapter.title,
      novelId: chapter.novelId
    });
  } catch (err: any) {
    console.error('Chapter audio access error:', err);
    return res.status(500).json({ ok: false, error: err.message || 'Telegram ऑडियो लिंक प्राप्त करने में त्रुटि' });
  }
};

router.post('/chapters/:chapterId/audio', optionalAuth, handleChapterAudioAccess);
router.get('/chapters/:chapterId/audio', optionalAuth, handleChapterAudioAccess);

// ==========================================
// 3. ADMIN ENDPOINTS
// ==========================================

/**
 * Check bot health, configuration, and webhook status
 */
router.get('/admin/bot-status', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const isConfigured = telegramService.isConfigured();
    const webhookSecret = process.env.TELEGRAM_WEBHOOK_SECRET?.trim() || '';
    const secretConfigured = Boolean(webhookSecret && webhookSecret.length >= 8);

    if (!isConfigured) {
      return res.json({
        ok: true,
        configured: false,
        botUsername: telegramService.botUsername,
        message: 'TELEGRAM_BOT_TOKEN environment variable is not configured',
        secretConfigured,
        webhookSecretWarning: secretConfigured
          ? null
          : 'TELEGRAM_WEBHOOK_SECRET पर्यावरण चर (env var) सेट नहीं है। सुरक्षा के लिए वेबहुक अनुरोध अस्वीकार (403) किए जाएंगे।',
        deduplicationActive: true,
      });
    }

    const [meRes, webhookRes] = await Promise.all([
      telegramService.getMe(),
      telegramService.getWebhookInfo(),
    ]);

    res.json({
      ok: true,
      configured: true,
      bot: meRes.result || null,
      botError: meRes.ok ? null : meRes.description,
      webhook: webhookRes.result || null,
      webhookError: webhookRes.ok ? null : webhookRes.description,
      envUsername: telegramService.botUsername,
      secretConfigured,
      webhookSecretWarning: secretConfigured
        ? null
        : 'TELEGRAM_WEBHOOK_SECRET पर्यावरण चर (env var) सेट नहीं है। सुरक्षा के लिए वेबहुक अनुरोध 403 के साथ अस्वीकार किए जा रहे हैं। कृपया .env में गुप्त कुंजी सेट करें।',
      deduplicationActive: true,
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Configure / update Telegram Webhook
 */
router.post('/admin/set-webhook', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const { url, secret } = req.body;
    if (!url) {
      return res.status(400).json({ ok: false, error: 'Webhook URL is required' });
    }

    const setRes = await telegramService.setWebhook(url, secret);
    if (!setRes.ok) {
      return res.status(400).json({ ok: false, error: setRes.description });
    }

    res.json({ ok: true, message: 'Webhook set successfully', result: setRes });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Check bot admin status in a specific channel
 */
router.post('/admin/check-channel', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const { channelId } = req.body;
    if (!channelId) {
      return res.status(400).json({ ok: false, error: 'channelId is required' });
    }

    const status = await telegramService.checkBotAdminStatus(channelId);
    res.json({ ok: true, status });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Full admin overview: channels, linked users, access logs, pending retries
 */
router.get('/admin/overview', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const [allNovels, allUsers, allAccesses, logs, pendingOps] = await Promise.all([
      db.getNovels(),
      db.getUsers(),
      db.getAllTelegramAccesses(),
      db.getTelegramLogs(100),
      db.getPendingTelegramOps(),
    ]);

    const channels = allNovels
      .filter((n: Novel) => n.telegramChannelId || n.telegramChannelLink || n.telegramIntegrationEnabled)
      .map((n: Novel) => ({
        novelId: n.id,
        novelTitle: n.title,
        channelPrivacy: n.telegramChannelPrivacy || (n.telegramChannelLink && !n.telegramChannelId ? 'public' : 'private'),
        channelLink: n.telegramChannelLink || '',
        channelId: n.telegramChannelId || '',
        channelName: n.telegramChannelName || '',
        channelType: n.telegramChannelType || 'channel',
        accessType: n.telegramAccessType || (n.isPremium ? 'premium' : 'free'),
        enabled: Boolean(n.telegramIntegrationEnabled),
      }));

    const linkedUsers = allUsers
      .filter((u: User) => u.telegram?.telegramUserId)
      .map((u: User) => ({
        id: u.id,
        name: u.name,
        email: u.email,
        role: u.role,
        isVip: userHasActiveVip(u),
        vipExpiresAt: u.membership?.expiresAt,
        telegram: u.telegram,
      }));

    res.json({
      ok: true,
      channels,
      linkedUsers,
      accesses: allAccesses,
      recentLogs: logs,
      pendingOps,
    });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Manually trigger expiry processor
 */
router.post('/admin/process-expiries', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const result = await telegramService.processMembershipExpiries();
    res.json({ ok: true, result });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Manually retry a specific pending removal
 */
router.post('/admin/retry-pending/:id', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const result = await telegramService.retryPendingOp(req.params.id);
    if (!result.ok) {
      return res.status(400).json({ ok: false, error: result.message });
    }
    res.json({ ok: true, message: result.message });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

/**
 * Manually retry all pending removal operations
 */
router.post('/admin/retry-all-pending', requireAdmin, async (req: AuthRequest, res) => {
  try {
    const summary = await telegramService.retryAllPendingOps();
    res.json({ ok: true, summary });
  } catch (err: any) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

export default router;
