import { db } from './db.js';
import type { TelegramAccessRecord, TelegramPendingOperation, TelegramAccessLog, Novel, User } from './types.js';

const TELEGRAM_API_BASE = 'https://api.telegram.org';

export interface TelegramBotInfo {
  id: number;
  is_bot: boolean;
  first_name: string;
  username: string;
  can_join_groups?: boolean;
  can_read_all_group_messages?: boolean;
  supports_inline_queries?: boolean;
}

export interface TelegramInviteLinkResult {
  invite_link: string;
  creator?: any;
  creates_join_request?: boolean;
  is_primary?: boolean;
  is_revoked?: boolean;
  name?: string;
  expire_date?: number;
  member_limit?: number;
  pending_join_request_count?: number;
}

export function isTelegramInviteUrl(val: string | number | undefined | null): boolean {
  if (!val) return false;
  const s = String(val).trim().toLowerCase();
  return (
    s.startsWith('http://') ||
    s.startsWith('https://') ||
    s.startsWith('t.me/') ||
    s.includes('t.me/+') ||
    s.includes('/+') ||
    s.includes('joinchat')
  );
}

export class TelegramService {
  private cachedBotUsername?: string;

  private get token(): string | undefined {
    return process.env.TELEGRAM_BOT_TOKEN?.trim();
  }

  public get botUsername(): string {
    if (this.cachedBotUsername) {
      return this.cachedBotUsername.replace(/^@/, '');
    }
    const raw = process.env.TELEGRAM_BOT_USERNAME?.trim() || '';
    // If user mistakenly placed bot token into TELEGRAM_BOT_USERNAME
    if (raw && !raw.includes(':') && !/^\d+$/.test(raw)) {
      return raw.replace(/^@/, '');
    }
    return 'CrazyStoryesManagerBot';
  }

  public get webhookSecret(): string {
    return process.env.TELEGRAM_WEBHOOK_SECRET?.trim() || 'crazy_storyes_secret_2026';
  }

  public isConfigured(): boolean {
    return Boolean(this.token && this.token.length > 10);
  }

  private async callApi<T = any>(
    method: string,
    params: Record<string, any> = {}
  ): Promise<{ ok: boolean; result?: T; description?: string; error_code?: number }> {
    if (!this.token) {
      return { ok: false, description: 'TELEGRAM_BOT_TOKEN is not configured on the server' };
    }

    try {
      const url = `${TELEGRAM_API_BASE}/bot${this.token}/${method}`;
      const response = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
        signal: AbortSignal.timeout(8000),
      });

      const data = await response.json();
      return data;
    } catch (err: any) {
      return { ok: false, description: err?.message || 'Network error calling Telegram Bot API' };
    }
  }

  public async getMe(): Promise<{ ok: boolean; result?: TelegramBotInfo; description?: string }> {
    const res = await this.callApi<TelegramBotInfo>('getMe');
    if (res.ok && res.result?.username) {
      this.cachedBotUsername = res.result.username;
    }
    return res;
  }

  public async getWebhookInfo(): Promise<{ ok: boolean; result?: any; description?: string }> {
    return this.callApi('getWebhookInfo');
  }

  public async setWebhook(url: string, secretToken?: string): Promise<{ ok: boolean; description?: string }> {
    return this.callApi('setWebhook', {
      url,
      secret_token: secretToken || this.webhookSecret,
      allowed_updates: ['message', 'chat_member', 'my_chat_member'],
    });
  }

  public async getChat(chatId: string | number): Promise<{ ok: boolean; result?: any; description?: string }> {
    if (isTelegramInviteUrl(chatId)) {
      return {
        ok: false,
        description: 'इनवाइट लिंक (URL) को संख्यात्मक Chat ID के रूप में उपयोग नहीं किया जा सकता। कृपया संख्यात्मक ID (-100...) दर्ज करें।',
      };
    }
    return this.callApi('getChat', { chat_id: chatId });
  }

  public async getChatAdministrators(chatId: string | number): Promise<{ ok: boolean; result?: any[]; description?: string }> {
    if (isTelegramInviteUrl(chatId)) {
      return {
        ok: false,
        description: 'इनवाइट लिंक (URL) को संख्यात्मक Chat ID के रूप में उपयोग नहीं किया जा सकता। कृपया संख्यात्मक ID (-100...) दर्ज करें।',
      };
    }
    return this.callApi('getChatAdministrators', { chat_id: chatId });
  }

  public async checkBotAdminStatus(chatId: string | number): Promise<{
    isAdmin: boolean;
    canInviteUsers: boolean;
    canRestrictMembers: boolean;
    title?: string;
    error?: string;
  }> {
    if (!chatId) {
      return {
        isAdmin: false,
        canInviteUsers: false,
        canRestrictMembers: false,
        error: 'Telegram Chat ID दर्ज नहीं की गई है',
      };
    }

    if (isTelegramInviteUrl(chatId)) {
      return {
        isAdmin: false,
        canInviteUsers: false,
        canRestrictMembers: false,
        error: '⚠️ यह एक इनवाइट लिंक (URL) है, संख्यात्मक Chat ID नहीं! बॉट को संख्यात्मक Chat ID (उदा. -100xxxxxxxxxx) की आवश्यकता होती है। यदि यह पब्लिक चैनल है, तो "पब्लिक चैनल" विकल्प चुनें।',
      };
    }

    const chatRes = await this.getChat(chatId);
    if (!chatRes.ok) {
      return {
        isAdmin: false,
        canInviteUsers: false,
        canRestrictMembers: false,
        error: chatRes.description || 'ग्रुप/चैनल नहीं मिला या बॉट अभी इसमें नहीं जुड़ा है। सुनिश्चित करें कि बॉट को इस ग्रुप में जोड़कर एडमिन बनाया गया है।',
      };
    }

    const title = chatRes.result?.title || 'Telegram Group / Channel';
    const adminsRes = await this.getChatAdministrators(chatId);
    if (!adminsRes.ok) {
      return {
        isAdmin: false,
        canInviteUsers: false,
        canRestrictMembers: false,
        title,
        error: adminsRes.description || 'बॉट एडमिनिस्ट्रेटर सूची नहीं देख सका। सुनिश्चित करें कि बॉट एडमिन है।',
      };
    }

    const meRes = await this.getMe();
    const botId = meRes.result?.id;

    const botAdmin = (adminsRes.result || []).find((admin: any) => admin.user?.id === botId);
    if (!botAdmin) {
      return {
        isAdmin: false,
        canInviteUsers: false,
        canRestrictMembers: false,
        title,
        error: `बॉट (@${this.botUsername}) इस ग्रुप में एडमिन के रूप में नहीं जोड़ा गया है। कृपया ग्रुप सेटिंग में जाकर बॉट को एडमिन बनाएं।`,
      };
    }

    return {
      isAdmin: true,
      canInviteUsers: Boolean(botAdmin.can_invite_users || botAdmin.status === 'creator'),
      canRestrictMembers: Boolean(botAdmin.can_restrict_members || botAdmin.can_manage_chat || botAdmin.status === 'creator'),
      title,
    };
  }

  public async createSingleUseInviteLink(
    chatId: string | number,
    name = 'CrazyStoryes Access Link',
    expireMinutes = 10
  ): Promise<{ ok: boolean; inviteLink?: string; description?: string; expireDate?: number }> {
    if (isTelegramInviteUrl(chatId)) {
      return {
        ok: false,
        description: 'Cannot use Invite URL as numeric Telegram Chat ID. Please provide numeric Chat ID (starting with -100...).',
      };
    }

    const expireDate = Math.floor(Date.now() / 1000) + expireMinutes * 60;
    const res = await this.callApi<TelegramInviteLinkResult>('createChatInviteLink', {
      chat_id: chatId,
      name,
      expire_date: expireDate,
      member_limit: 1, // Single-use constraint
      creates_join_request: false,
    });

    if (!res.ok || !res.result?.invite_link) {
      return {
        ok: false,
        description: res.description || 'Failed to create single-use invite link',
      };
    }

    return {
      ok: true,
      inviteLink: res.result.invite_link,
      expireDate: expireDate * 1000,
    };
  }

  public async removeUserFromChannel(
    chatId: string | number,
    userId: number
  ): Promise<{ ok: boolean; description?: string }> {
    // Ban member briefly to kick them from the channel
    const banRes = await this.callApi('banChatMember', {
      chat_id: chatId,
      user_id: userId,
      until_date: Math.floor(Date.now() / 1000) + 60, // 60 seconds
    });

    if (!banRes.ok) {
      return {
        ok: false,
        description: banRes.description || 'Failed to ban/kick member from channel',
      };
    }

    // Immediately unban so they can rejoin whenever they renew membership
    await this.callApi('unbanChatMember', {
      chat_id: chatId,
      user_id: userId,
      only_if_banned: true,
    });

    return { ok: true };
  }

  public async sendMessage(
    chatId: string | number,
    text: string,
    parseMode: 'HTML' | 'Markdown' | 'MarkdownV2' = 'HTML',
    replyMarkup?: any
  ): Promise<{ ok: boolean; description?: string }> {
    return this.callApi('sendMessage', {
      chat_id: chatId,
      text,
      parse_mode: parseMode,
      reply_markup: replyMarkup,
      disable_web_page_preview: false,
    });
  }

  /**
   * Periodic runner: checks for expired VIP subscriptions and removes users from VIP Telegram channels.
   * Also retries failed pending removal operations.
   */
  public async processMembershipExpiries(): Promise<{
    processedUsers: number;
    kickedCount: number;
    errorsCount: number;
    details: string[];
  }> {
    const details: string[] = [];
    let processedUsers = 0;
    let kickedCount = 0;
    let errorsCount = 0;

    try {
      const now = Date.now();
      const nowIso = new Date().toISOString();
      const users: User[] = await db.getUsers();
      const novels: Novel[] = await db.getNovels();

      // Find users with expired VIP
      for (const user of users) {
        if (user.role === 'admin') continue; // Admins never expire

        const isVipMarked = user.membership?.isActive;
        const expiresAt = user.membership?.expiresAt;
        const isExpired = isVipMarked && expiresAt && new Date(expiresAt).getTime() <= now;

        if (isExpired) {
          processedUsers++;
          details.push(`User ${user.email} (ID: ${user.id}) VIP expired on ${new Date(expiresAt).toLocaleString()}`);

          // Update user membership status to inactive
          await db.updateUser(user.id, {
            membership: {
              ...user.membership,
              isActive: false,
            },
          });

          // Get their active Telegram accesses
          const userAccesses = await db.getUserTelegramAccesses(user.id);
          const activeVipAccesses = userAccesses.filter((a) => a.accessType === 'premium' && a.status === 'active');

          for (const access of activeVipAccesses) {
            const novel = novels.find((n: Novel) => n.id === access.novelId);
            const channelId = access.channelId || novel?.telegramChannelId;
            const telegramUserId = access.telegramUserId || user.telegram?.telegramUserId;

            if (channelId && telegramUserId) {
              // Also revoke any stored single-use invite link for this access
              if (access.inviteLink && isTelegramInviteUrl(access.inviteLink)) {
                await this.callApi('revokeChatInviteLink', {
                  chat_id: channelId,
                  invite_link: access.inviteLink,
                }).catch(() => {});
              }

              const kickRes = await this.removeUserFromChannel(channelId, telegramUserId);
              if (kickRes.ok) {
                kickedCount++;
                await db.updateTelegramAccess(access.id, {
                  status: 'expired',
                  updatedAt: nowIso,
                });
                await db.addTelegramLog({
                  id: `tlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
                  userId: user.id,
                  telegramUserId,
                  channelId,
                  novelId: access.novelId,
                  action: 'member_removed',
                  status: 'success',
                  details: 'VIP membership expired auto-cleanup across all VIP channels',
                  createdAt: nowIso,
                });
                details.push(`✓ Removed @${user.telegram?.telegramUsername || telegramUserId} from ${access.novelTitle || channelId}`);
              } else {
                errorsCount++;
                details.push(`✗ Failed to remove @${user.telegram?.telegramUsername || telegramUserId} from ${access.novelTitle || channelId}: ${kickRes.description}`);
                await db.addTelegramLog({
                  id: `tlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
                  userId: user.id,
                  telegramUserId,
                  channelId,
                  novelId: access.novelId,
                  action: 'removal_failed',
                  status: 'failed',
                  details: `Bot kick failed: ${kickRes.description}`,
                  createdAt: nowIso,
                });

                // Check for existing pending op to prevent duplicates
                const existingPending = await db.getPendingTelegramOps();
                const alreadyQueued = existingPending.some(
                  (p) =>
                    p.status === 'pending' &&
                    p.operationType === 'remove_member' &&
                    p.channelId === channelId &&
                    p.telegramUserId === telegramUserId
                );

                if (!alreadyQueued) {
                  await db.addTelegramPendingOp({
                    id: `top_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
                    operationType: 'remove_member',
                    userId: user.id,
                    telegramUserId,
                    channelId,
                    novelId: access.novelId,
                    retryCount: 1,
                    lastError: kickRes.description,
                    status: 'pending',
                    createdAt: nowIso,
                    updatedAt: nowIso,
                  });
                }
              }
            } else {
              // Just mark expired in DB if no channel ID or Telegram ID
              await db.updateTelegramAccess(access.id, {
                status: 'expired',
                updatedAt: nowIso,
              });
            }
          }

          // Send friendly Hindi notification to user via bot if they linked Telegram
          if (user.telegram?.telegramUserId) {
            await this.sendMessage(
              user.telegram.telegramUserId,
              `⚠️ <b>Crazy Storyes – VIP सब्सक्रिप्शन समाप्त</b>\n\n` +
              `नमस्ते ${user.telegram.telegramFirstName || user.name || 'दोस्त'}!\n` +
              `आपका Crazy Storyes VIP सब्सक्रिप्शन समाप्त हो गया है। इसलिए VIP ऑडियो चैनल्स और ग्रुप्स का एक्सेस स्वतः रिवोक कर दिया गया है।\n\n` +
              `🔄 पुनः सभी VIP उपन्यासों, ऑडियो चैप्टर्स और स्पेशल कंटेंट का आनंद लेने के लिए वेबसाइट पर जाकर अपना VIP प्लान रिन्यू करें।\n\n` +
              `धन्यवाद!`
            );
          }
        }
      }

      // Retry pending operations
      const pendingOps = await db.getPendingTelegramOps();
      for (const op of pendingOps) {
        if (op.retryCount >= 5) {
          await db.updateTelegramPendingOp(op.id, { status: 'failed', updatedAt: nowIso });
          continue;
        }

        if (op.operationType === 'remove_member') {
          const res = await this.removeUserFromChannel(op.channelId, op.telegramUserId);
          if (res.ok) {
            await db.updateTelegramPendingOp(op.id, { status: 'completed', updatedAt: nowIso });
            await db.addTelegramLog({
              id: `tlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
              userId: op.userId,
              telegramUserId: op.telegramUserId,
              channelId: op.channelId,
              novelId: op.novelId,
              action: 'retry_removal',
              status: 'success',
              details: `Retry successful after ${op.retryCount} attempts`,
              createdAt: nowIso,
            });
            details.push(`✓ Retry succeeded: kicked ${op.telegramUserId} from ${op.channelId}`);
          } else {
            const nextCount = op.retryCount + 1;
            await db.updateTelegramPendingOp(op.id, {
              retryCount: nextCount,
              lastError: res.description,
              status: nextCount >= 5 ? 'failed' : 'pending',
              updatedAt: nowIso,
            });
          }
        }
      }
    } catch (err: any) {
      details.push(`Fatal error in processMembershipExpiries: ${err.message}`);
      errorsCount++;
    }

    return { processedUsers, kickedCount, errorsCount, details };
  }

  /**
   * Manually retry a specific pending operation
   */
  public async retryPendingOp(opId: string): Promise<{ ok: boolean; message: string }> {
    const ops = await db.getPendingTelegramOps();
    const op = ops.find((o) => o.id === opId);
    if (!op) return { ok: false, message: 'लंबित ऑपरेशन नहीं मिला' };

    const nowIso = new Date().toISOString();
    if (op.operationType === 'remove_member') {
      const res = await this.removeUserFromChannel(op.channelId, op.telegramUserId);
      if (res.ok) {
        await db.updateTelegramPendingOp(op.id, { status: 'completed', updatedAt: nowIso });
        await db.addTelegramLog({
          id: `tlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
          userId: op.userId,
          telegramUserId: op.telegramUserId,
          channelId: op.channelId,
          novelId: op.novelId,
          action: 'retry_removal',
          status: 'success',
          details: 'Manual admin retry removal successful',
          createdAt: nowIso,
        });
        return { ok: true, message: `सफलतापूर्वक चैनल से हटाया गया (${op.telegramUserId})` };
      } else {
        await db.updateTelegramPendingOp(op.id, {
          retryCount: op.retryCount + 1,
          lastError: res.description,
          updatedAt: nowIso,
        });
        return { ok: false, message: res.description || 'पुनः प्रयास विफल रहा' };
      }
    }

    return { ok: false, message: 'असमर्थित ऑपरेशन प्रकार' };
  }

  /**
   * Manually retry all pending removal operations
   */
  public async retryAllPendingOps(): Promise<{ total: number; succeeded: number; failed: number }> {
    const ops = await db.getPendingTelegramOps();
    const pendingList = ops.filter((o) => o.status === 'pending');
    let succeeded = 0;
    let failed = 0;

    for (const op of pendingList) {
      const res = await this.retryPendingOp(op.id);
      if (res.ok) succeeded++;
      else failed++;
    }

    return { total: pendingList.length, succeeded, failed };
  }
}

export const telegramService = new TelegramService();
