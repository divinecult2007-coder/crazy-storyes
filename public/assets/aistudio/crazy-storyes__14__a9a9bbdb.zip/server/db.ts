import path from 'path';
import fs from 'fs';
import {
  supabase,
  isSupabaseConfigured,
  userToRow,
  userPartialToRow,
  rowToUser,
  novelToRow,
  novelPartialToRow,
  rowToNovel,
  chapterToRow,
  chapterPartialToRow,
  rowToChapter,
  paymentToRow,
  paymentPartialToRow,
  rowToPayment,
  planToRow,
  rowToPlan,
  settingsToRow,
  settingsPartialToRow,
  rowToSettings,
  ticketToRow,
  rowToTicket,
  telegramAccessToRow,
  rowToTelegramAccess,
  telegramLinkCodeToRow,
  rowToTelegramLinkCode,
  telegramLogToRow,
  rowToTelegramLog,
  telegramPendingOpToRow,
  rowToTelegramPendingOp,
  authLogToRow,
  rowToAuthLog,
  revokedTokenToRow,
  rowToRevokedToken
} from './supabase.js';
import {
  DatabaseSchema,
  Novel,
  Chapter,
  User,
  MembershipPlan,
  SiteSettings,
  PaymentRequest,
  SupportTicket,
  TelegramAccessRecord,
  TelegramLinkCode,
  TelegramAccessLog,
  TelegramPendingOperation,
  UserAuthLog,
  RevokedToken
} from './types.js';
import {
  initialSettings,
  initialPlans,
  initialNovels,
  initialChapters,
  initialUsers
} from './seedData.js';

const DATA_DIR = path.resolve(process.cwd(), 'data');
export const UPLOADS_DIR = path.join(DATA_DIR, 'uploads');
export const PRIVATE_SCREENSHOTS_DIR = path.join(DATA_DIR, 'private_screenshots');

// Ensure directories exist for binary file uploads (images/audio/screenshots)
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}
if (!fs.existsSync(PRIVATE_SCREENSHOTS_DIR)) {
  fs.mkdirSync(PRIVATE_SCREENSHOTS_DIR, { recursive: true });
}

class Database {
  // In-memory synchronized store (zero JSON file writes)
  private cache: DatabaseSchema = {
    users: [...initialUsers],
    novels: [...initialNovels],
    chapters: [...initialChapters],
    payments: [],
    membershipPlans: [...initialPlans],
    settings: { ...initialSettings },
    supportTickets: [],
    telegramLinkCodes: [],
    telegramAccess: [],
    telegramAccessLogs: [],
    telegramPendingOperations: [],
    userAuthLogs: [],
    revokedTokens: []
  };

  private isInitialized = false;

  constructor() {
    this.init().catch(err => {
      console.error('Error during database initialization:', err);
    });
  }

  /**
   * Initializes database with Supabase tables.
   * If tables are empty, seeds initial data directly into Supabase.
   */
  public async init() {
    if (this.isInitialized) return;
    this.isInitialized = true;

    if (!isSupabaseConfigured() || !supabase) {
      console.log('⚡ Running on in-memory store (zero local JSON file writes). Supabase URL & Key can be configured in .env.');
      return;
    }

    try {
      console.log('🔄 Syncing with Supabase database...');

      // 1. Check & Seed Settings
      const { data: settingsData, error: settingsErr } = await supabase
        .from('site_settings')
        .select('*')
        .eq('id', 'current')
        .maybeSingle();

      if (!settingsData && !settingsErr) {
        console.log('🌱 Seeding initial settings to Supabase...');
        await supabase.from('site_settings').upsert(settingsToRow(this.cache.settings));
      } else if (settingsData) {
        this.cache.settings = rowToSettings(settingsData);
      }

      // 2. Check & Seed Membership Plans
      const { data: plansData } = await supabase.from('membership_plans').select('*');
      if (!plansData || plansData.length === 0) {
        console.log('🌱 Seeding initial membership plans to Supabase...');
        await supabase.from('membership_plans').upsert(this.cache.membershipPlans.map(planToRow));
      } else {
        this.cache.membershipPlans = plansData.map(rowToPlan);
      }

      // 3. Check & Seed Users
      const { data: usersData } = await supabase.from('users').select('*');
      if (!usersData || usersData.length === 0) {
        console.log('🌱 Seeding initial users to Supabase...');
        await supabase.from('users').upsert(this.cache.users.map(userToRow));
      } else {
        this.cache.users = usersData.map(rowToUser);
      }

      // 4. Check & Seed Novels
      const { data: novelsData } = await supabase.from('novels').select('*');
      if (!novelsData || novelsData.length === 0) {
        console.log('🌱 Seeding initial novels to Supabase...');
        await supabase.from('novels').upsert(this.cache.novels.map(novelToRow));
      } else {
        this.cache.novels = novelsData.map(rowToNovel);
        const n2 = this.cache.novels.find(n => n.id === 'novel_2');
        if (n2 && (n2.coverImage.includes('photo-1509198397868') || !n2.coverImage)) {
          n2.coverImage = 'https://images.unsplash.com/photo-1464822759023-fed622ff2c3b?w=1280&h=720&fit=crop&q=80';
          await supabase.from('novels').update({ cover_image: n2.coverImage }).eq('id', 'novel_2');
        }
      }

      // 5. Check & Seed Chapters
      const { data: chaptersData } = await supabase.from('chapters').select('*');
      if (!chaptersData || chaptersData.length === 0) {
        console.log('🌱 Seeding initial chapters to Supabase...');
        await supabase.from('chapters').upsert(this.cache.chapters.map(chapterToRow));
      } else {
        this.cache.chapters = chaptersData.map(rowToChapter);
      }

      // 6. Load Payments
      const { data: paymentsData } = await supabase.from('payments').select('*').order('created_at', { ascending: false });
      if (paymentsData) {
        this.cache.payments = paymentsData.map(rowToPayment);
      }

      // 7. Load Support Tickets
      const { data: ticketsData } = await supabase.from('support_tickets').select('*').order('created_at', { ascending: false });
      if (ticketsData) {
        this.cache.supportTickets = ticketsData.map(rowToTicket);
      }

      console.log(`✅ Supabase database synchronized: ${this.cache.novels.length} novels, ${this.cache.chapters.length} chapters, ${this.cache.users.length} users, ${this.cache.payments.length} payments.`);
    } catch (err) {
      console.error('Error during Supabase sync:', err);
    }
  }

  // -------------------------------------------------------------
  // USERS
  // -------------------------------------------------------------
  public async getUsers(): Promise<User[]> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase.from('users').select('*').order('created_at', { ascending: false });
      if (!error && data) {
        this.cache.users = data.map(rowToUser);
      }
    }
    return this.cache.users;
  }

  public getUsersSync(): User[] {
    return this.cache.users;
  }

  public async getUserById(id: string): Promise<User | undefined> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase.from('users').select('*').eq('id', id).maybeSingle();
      if (!error && data) {
        const u = rowToUser(data);
        const idx = this.cache.users.findIndex(x => x.id === id);
        if (idx !== -1) this.cache.users[idx] = u;
        else this.cache.users.push(u);
        return u;
      }
    }
    return this.cache.users.find(u => u.id === id);
  }

  public getUserByIdSync(id: string): User | undefined {
    return this.cache.users.find(u => u.id === id);
  }

  public async getUserByEmail(email: string): Promise<User | undefined> {
    const cleanEmail = email.toLowerCase().trim();
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .ilike('email', cleanEmail)
        .maybeSingle();
      if (!error && data) {
        const u = rowToUser(data);
        const idx = this.cache.users.findIndex(x => x.id === u.id);
        if (idx !== -1) this.cache.users[idx] = u;
        else this.cache.users.push(u);
        return u;
      }
    }
    return this.cache.users.find(u => u.email.toLowerCase() === cleanEmail);
  }

  public async addUser(user: User): Promise<User> {
    this.cache.users.push(user);
    if (isSupabaseConfigured() && supabase) {
      const row = userToRow(user);
      const { data, error } = await supabase.from('users').insert(row).select().single();
      if (error) {
        console.error('Supabase addUser error:', error);
        throw new Error(`Supabase error (addUser): ${error.message}`);
      } else if (data) {
        return rowToUser(data);
      }
    }
    return user;
  }

  public async updateUser(id: string, updates: Partial<User>): Promise<User | undefined> {
    const idx = this.cache.users.findIndex(u => u.id === id);
    if (idx !== -1) {
      this.cache.users[idx] = { ...this.cache.users[idx], ...updates };
    }

    if (isSupabaseConfigured() && supabase) {
      const rowUpdates = userPartialToRow(updates);
      const { data, error } = await supabase
        .from('users')
        .update(rowUpdates)
        .eq('id', id)
        .select()
        .single();
      if (error) {
        console.error('Supabase updateUser error:', error);
        throw new Error(`Supabase error (updateUser): ${error.message}`);
      } else if (data) {
        const updated = rowToUser(data);
        if (idx !== -1) this.cache.users[idx] = updated;
        return updated;
      }
    }
    return idx !== -1 ? this.cache.users[idx] : undefined;
  }

  public async deleteUser(id: string): Promise<boolean> {
    this.cache.users = this.cache.users.filter(u => u.id !== id);
    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('users').delete().eq('id', id);
      if (error) {
        console.error('Supabase deleteUser error:', error);
        return false;
      }
    }
    return true;
  }

  // -------------------------------------------------------------
  // NOVELS
  // -------------------------------------------------------------
  public async getNovels(): Promise<Novel[]> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase.from('novels').select('*').order('created_at', { ascending: false });
      if (!error && data) {
        this.cache.novels = data.map(rowToNovel);
      }
    }
    return this.cache.novels;
  }

  public getNovelsSync(): Novel[] {
    return this.cache.novels;
  }

  public async getNovelById(id: string): Promise<Novel | undefined> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase.from('novels').select('*').eq('id', id).maybeSingle();
      if (!error && data) {
        const n = rowToNovel(data);
        const idx = this.cache.novels.findIndex(x => x.id === id);
        if (idx !== -1) this.cache.novels[idx] = n;
        else this.cache.novels.push(n);
        return n;
      }
    }
    return this.cache.novels.find(n => n.id === id);
  }

  public getNovelByIdSync(id: string): Novel | undefined {
    return this.cache.novels.find(n => n.id === id);
  }

  public async addNovel(novel: Novel): Promise<Novel> {
    this.cache.novels.unshift(novel);
    if (isSupabaseConfigured() && supabase) {
      const row = novelToRow(novel);
      const { data, error } = await supabase.from('novels').insert(row).select().single();
      if (error) {
        console.error('Supabase addNovel error:', error);
        throw new Error(`Supabase error (addNovel): ${error.message}`);
      } else if (data) {
        return rowToNovel(data);
      }
    }
    return novel;
  }

  public async updateNovel(id: string, updates: Partial<Novel>): Promise<Novel | undefined> {
    const idx = this.cache.novels.findIndex(n => n.id === id);
    if (idx !== -1) {
      this.cache.novels[idx] = {
        ...this.cache.novels[idx],
        ...updates,
        updatedAt: new Date().toISOString()
      };
    }

    if (isSupabaseConfigured() && supabase) {
      const rowUpdates = novelPartialToRow(updates);
      const { data, error } = await supabase
        .from('novels')
        .update(rowUpdates)
        .eq('id', id)
        .select()
        .single();
      if (error) {
        console.error('Supabase updateNovel error:', error);
        throw new Error(`Supabase error (updateNovel): ${error.message}`);
      } else if (data) {
        const updated = rowToNovel(data);
        if (idx !== -1) this.cache.novels[idx] = updated;
        return updated;
      }
    }
    return idx !== -1 ? this.cache.novels[idx] : undefined;
  }

  public async deleteNovel(id: string): Promise<boolean> {
    this.cache.novels = this.cache.novels.filter(n => n.id !== id);
    this.cache.chapters = this.cache.chapters.filter(c => c.novelId !== id);

    if (isSupabaseConfigured() && supabase) {
      const { error: chErr } = await supabase.from('chapters').delete().eq('novel_id', id);
      if (chErr) {
        console.error('Supabase delete chapters for novel error:', chErr);
        throw new Error(`Supabase error (deleteChapters): ${chErr.message}`);
      }
      const { error } = await supabase.from('novels').delete().eq('id', id);
      if (error) {
        console.error('Supabase deleteNovel error:', error);
        throw new Error(`Supabase error (deleteNovel): ${error.message}`);
      }
    }
    return true;
  }

  // -------------------------------------------------------------
  // CHAPTERS
  // -------------------------------------------------------------
  public async getChapters(novelId?: string): Promise<Chapter[]> {
    if (isSupabaseConfigured() && supabase) {
      let query = supabase.from('chapters').select('*').order('chapter_number', { ascending: true });
      if (novelId) query = query.eq('novel_id', novelId);
      const { data, error } = await query;
      if (!error && data) {
        const fetched = data.map(rowToChapter);
        if (novelId) {
          this.cache.chapters = [
            ...this.cache.chapters.filter(c => c.novelId !== novelId),
            ...fetched
          ];
        } else {
          this.cache.chapters = fetched;
        }
        return fetched;
      }
    }

    if (novelId) {
      return this.cache.chapters
        .filter(c => c.novelId === novelId)
        .sort((a, b) => a.chapterNumber - b.chapterNumber);
    }
    return this.cache.chapters.sort((a, b) => a.chapterNumber - b.chapterNumber);
  }

  public getChaptersSync(novelId?: string): Chapter[] {
    if (novelId) {
      return this.cache.chapters
        .filter(c => c.novelId === novelId)
        .sort((a, b) => a.chapterNumber - b.chapterNumber);
    }
    return this.cache.chapters.sort((a, b) => a.chapterNumber - b.chapterNumber);
  }

  public async getChapterById(id: string): Promise<Chapter | undefined> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase.from('chapters').select('*').eq('id', id).maybeSingle();
      if (!error && data) {
        const ch = rowToChapter(data);
        const idx = this.cache.chapters.findIndex(c => c.id === id);
        if (idx !== -1) this.cache.chapters[idx] = ch;
        else this.cache.chapters.push(ch);
        return ch;
      }
    }
    return this.cache.chapters.find(c => c.id === id);
  }

  public getChapterByIdSync(id: string): Chapter | undefined {
    return this.cache.chapters.find(c => c.id === id);
  }

  public async addChapter(chapter: Chapter): Promise<Chapter> {
    this.cache.chapters.push(chapter);
    const count = this.cache.chapters.filter(c => c.novelId === chapter.novelId).length;
    await this.updateNovel(chapter.novelId, { totalChapters: count });

    if (isSupabaseConfigured() && supabase) {
      const row = chapterToRow(chapter);
      const { data, error } = await supabase.from('chapters').insert(row).select().single();
      if (error) {
        console.error('Supabase addChapter error:', error);
        throw new Error(`Supabase error (addChapter): ${error.message}`);
      } else if (data) {
        return rowToChapter(data);
      }
    }
    return chapter;
  }

  public async updateChapter(id: string, updates: Partial<Chapter>): Promise<Chapter | undefined> {
    const idx = this.cache.chapters.findIndex(c => c.id === id);
    if (idx !== -1) {
      this.cache.chapters[idx] = {
        ...this.cache.chapters[idx],
        ...updates,
        updatedAt: new Date().toISOString()
      };
    }

    if (isSupabaseConfigured() && supabase) {
      const rowUpdates = chapterPartialToRow(updates);
      const { data, error } = await supabase
        .from('chapters')
        .update(rowUpdates)
        .eq('id', id)
        .select()
        .single();
      if (error) {
        console.error('Supabase updateChapter error:', error);
        throw new Error(`Supabase error (updateChapter): ${error.message}`);
      } else if (data) {
        const updated = rowToChapter(data);
        if (idx !== -1) this.cache.chapters[idx] = updated;
        return updated;
      }
    }
    return idx !== -1 ? this.cache.chapters[idx] : undefined;
  }

  public async deleteChapter(id: string): Promise<boolean> {
    const chapter = await this.getChapterById(id);
    if (!chapter) return false;
    const novelId = chapter.novelId;

    this.cache.chapters = this.cache.chapters.filter(c => c.id !== id);
    const count = this.cache.chapters.filter(c => c.novelId === novelId).length;
    await this.updateNovel(novelId, { totalChapters: count });

    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('chapters').delete().eq('id', id);
      if (error) {
        console.error('Supabase deleteChapter error:', error);
        throw new Error(`Supabase error (deleteChapter): ${error.message}`);
      }
    }
    return true;
  }

  // -------------------------------------------------------------
  // PAYMENTS
  // -------------------------------------------------------------
  public async getPayments(): Promise<PaymentRequest[]> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase
        .from('payments')
        .select('*')
        .order('created_at', { ascending: false });
      if (!error && data) {
        this.cache.payments = data.map(rowToPayment);
      }
    }
    return this.cache.payments.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public getPaymentsSync(): PaymentRequest[] {
    return this.cache.payments.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public async getPaymentById(id: string): Promise<PaymentRequest | undefined> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase.from('payments').select('*').eq('id', id).maybeSingle();
      if (!error && data) {
        const p = rowToPayment(data);
        const idx = this.cache.payments.findIndex(x => x.id === id);
        if (idx !== -1) this.cache.payments[idx] = p;
        else this.cache.payments.unshift(p);
        return p;
      }
    }
    return this.cache.payments.find(p => p.id === id);
  }

  public async addPayment(payment: PaymentRequest): Promise<PaymentRequest> {
    this.cache.payments.unshift(payment);
    if (isSupabaseConfigured() && supabase) {
      const row = paymentToRow(payment);
      const { data, error } = await supabase.from('payments').insert(row).select().single();
      if (error) {
        console.error('Supabase addPayment error:', error);
        throw new Error(`Supabase error (addPayment): ${error.message}`);
      } else if (data) {
        return rowToPayment(data);
      }
    }
    return payment;
  }

  public async updatePayment(id: string, updates: Partial<PaymentRequest>): Promise<PaymentRequest | undefined> {
    const idx = this.cache.payments.findIndex(p => p.id === id);
    if (idx !== -1) {
      this.cache.payments[idx] = { ...this.cache.payments[idx], ...updates };
    }

    if (isSupabaseConfigured() && supabase) {
      const rowUpdates = paymentPartialToRow(updates);
      const { data, error } = await supabase
        .from('payments')
        .update(rowUpdates)
        .eq('id', id)
        .select()
        .single();
      if (error) {
        console.error('Supabase updatePayment error:', error);
        throw new Error(`Supabase error (updatePayment): ${error.message}`);
      } else if (data) {
        const updated = rowToPayment(data);
        if (idx !== -1) this.cache.payments[idx] = updated;
        return updated;
      }
    }
    return idx !== -1 ? this.cache.payments[idx] : undefined;
  }

  // -------------------------------------------------------------
  // MEMBERSHIP PLANS
  // -------------------------------------------------------------
  public async getPlans(): Promise<MembershipPlan[]> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase.from('membership_plans').select('*');
      if (!error && data) {
        this.cache.membershipPlans = data.map(rowToPlan);
      }
    }
    return this.cache.membershipPlans;
  }

  public getPlansSync(): MembershipPlan[] {
    return this.cache.membershipPlans;
  }

  public async updatePlans(plans: MembershipPlan[]): Promise<MembershipPlan[]> {
    this.cache.membershipPlans = plans;
    if (isSupabaseConfigured() && supabase) {
      const rows = plans.map(planToRow);
      await supabase.from('membership_plans').upsert(rows);
    }
    return this.cache.membershipPlans;
  }

  // -------------------------------------------------------------
  // SETTINGS
  // -------------------------------------------------------------
  public async getSettings(): Promise<SiteSettings> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase.from('site_settings').select('*').eq('id', 'current').maybeSingle();
      if (!error && data) {
        this.cache.settings = rowToSettings(data);
      }
    }
    return this.cache.settings;
  }

  public getSettingsSync(): SiteSettings {
    return this.cache.settings;
  }

  public async updateSettings(updates: Partial<SiteSettings>): Promise<SiteSettings> {
    this.cache.settings = { ...this.cache.settings, ...updates };
    if (isSupabaseConfigured() && supabase) {
      const row = settingsPartialToRow(updates);
      await supabase.from('site_settings').update(row).eq('id', 'current');
    }
    return this.cache.settings;
  }

  // -------------------------------------------------------------
  // SUPPORT TICKETS
  // -------------------------------------------------------------
  public async getSupportTickets(): Promise<SupportTicket[]> {
    if (isSupabaseConfigured() && supabase) {
      const { data, error } = await supabase
        .from('support_tickets')
        .select('*')
        .order('created_at', { ascending: false });
      if (!error && data) {
        this.cache.supportTickets = data.map(rowToTicket);
      }
    }
    return this.cache.supportTickets.sort(
      (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    );
  }

  public async addSupportTicket(ticket: SupportTicket): Promise<SupportTicket> {
    this.cache.supportTickets.unshift(ticket);
    if (isSupabaseConfigured() && supabase) {
      const row = ticketToRow(ticket);
      const { data, error } = await supabase.from('support_tickets').insert(row).select().single();
      if (error) {
        console.error('Supabase addSupportTicket error:', error);
      } else if (data) {
        return rowToTicket(data);
      }
    }
    return ticket;
  }

  public async updateSupportTicket(id: string, updates: Partial<SupportTicket>): Promise<SupportTicket | undefined> {
    const idx = this.cache.supportTickets.findIndex(t => t.id === id);
    if (idx !== -1) {
      this.cache.supportTickets[idx] = { ...this.cache.supportTickets[idx], ...updates };
    }

    if (isSupabaseConfigured() && supabase) {
      const rowUpdates: any = {};
      if (updates.adminReply !== undefined) rowUpdates.admin_reply = updates.adminReply;
      if (updates.status !== undefined) rowUpdates.status = updates.status;
      if (updates.repliedAt !== undefined) rowUpdates.replied_at = updates.repliedAt;

      const { data, error } = await supabase
        .from('support_tickets')
        .update(rowUpdates)
        .eq('id', id)
        .select()
        .single();
      if (error) {
        console.error('Supabase updateSupportTicket error:', error);
      } else if (data) {
        const updated = rowToTicket(data);
        if (idx !== -1) this.cache.supportTickets[idx] = updated;
        return updated;
      }
    }
    return idx !== -1 ? this.cache.supportTickets[idx] : undefined;
  }

  // -------------------------------------------------------------
  // TELEGRAM INTEGRATION METHODS
  // -------------------------------------------------------------

  public async createTelegramLinkCode(codeItem: TelegramLinkCode): Promise<TelegramLinkCode> {
    if (isSupabaseConfigured() && supabase) {
      const row = telegramLinkCodeToRow(codeItem);
      const { error } = await supabase.from('telegram_link_codes').insert(row);
      if (error) {
        console.error('Supabase telegram_link_codes insert error:', error);
        throw new Error(`Failed to persist telegram link code: ${error.message}`);
      }
    }

    this.cache.telegramLinkCodes = this.cache.telegramLinkCodes.filter(
      c => c.userId !== codeItem.userId && new Date(c.expiresAt).getTime() > Date.now()
    );
    this.cache.telegramLinkCodes.push(codeItem);
    return codeItem;
  }

  public async getTelegramLinkCode(code: string): Promise<TelegramLinkCode | null> {
    if (!code) return null;
    const cleanCode = code.trim().toLowerCase();

    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('telegram_link_codes')
          .select('*')
          .ilike('code', cleanCode)
          .is('used_at', null)
          .maybeSingle();

        if (error) {
          console.error('Supabase getTelegramLinkCode query error:', error);
          throw new Error(`Failed to read telegram link code: ${error.message}`);
        }

        if (data) {
          const item = rowToTelegramLinkCode(data);
          if (new Date(item.expiresAt).getTime() > Date.now()) {
            return item;
          }
        }
      } catch (err: any) {
        if (err.message?.includes('Failed to read telegram link code')) throw err;
        console.warn('Supabase getTelegramLinkCode error:', err);
      }
    }

    const cached = this.cache.telegramLinkCodes.find(
      c => c && c.code && c.code.toLowerCase() === cleanCode && !c.usedAt
    );
    if (cached && new Date(cached.expiresAt).getTime() > Date.now()) {
      return cached;
    }
    return null;
  }

  public async markTelegramLinkCodeUsed(idOrCode: string): Promise<void> {
    const clean = idOrCode.trim();
    const nowIso = new Date().toISOString();

    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase
        .from('telegram_link_codes')
        .update({ used_at: nowIso })
        .or(`id.eq.${clean},code.ilike.${clean}`);
      if (error) {
        console.error('Supabase markTelegramLinkCodeUsed error:', error);
        throw new Error(`Failed to mark telegram link code used: ${error.message}`);
      }
    }

    const idx = this.cache.telegramLinkCodes.findIndex(
      c => c && (c.id === clean || (c.code && c.code.toLowerCase() === clean.toLowerCase()))
    );
    if (idx !== -1) {
      this.cache.telegramLinkCodes[idx].usedAt = nowIso;
    }
  }

  public async getUserByTelegramId(telegramUserId: number): Promise<User | null> {
    const numId = Number(telegramUserId);
    if (isSupabaseConfigured() && supabase) {
      try {
        // 1. Try dedicated telegram_users table
        const { data: tgUser } = await supabase
          .from('telegram_users')
          .select('user_id')
          .eq('telegram_user_id', numId)
          .maybeSingle();

        if (tgUser?.user_id) {
          const user = await this.getUserById(tgUser.user_id);
          if (user) return user;
        }

        // 2. Try JSON telegram field on users table
        const { data: userData } = await supabase
          .from('users')
          .select('*')
          .filter('telegram->>telegramUserId', 'eq', String(numId))
          .maybeSingle();

        if (userData) {
          return rowToUser(userData);
        }
      } catch (err) {
        console.warn('Supabase getUserByTelegramId error:', err);
      }
    }

    const found = this.cache.users.find(
      u => u.telegram?.telegramUserId === numId
    );
    return found || null;
  }

  public async linkUserTelegram(
    userId: string,
    data: { telegramUserId: number; telegramUsername?: string; telegramFirstName?: string }
  ): Promise<User | null> {
    const nowIso = new Date().toISOString();
    const telegramPayload = {
      telegramUserId: Number(data.telegramUserId),
      telegramUsername: data.telegramUsername ? data.telegramUsername.replace(/^@/, '') : undefined,
      telegramFirstName: data.telegramFirstName,
      linkedAt: nowIso
    };

    if (isSupabaseConfigured() && supabase) {
      const { error: upsertErr } = await supabase.from('telegram_users').upsert({
        user_id: userId,
        telegram_user_id: telegramPayload.telegramUserId,
        telegram_username: telegramPayload.telegramUsername || null,
        telegram_first_name: telegramPayload.telegramFirstName || null,
        linked_at: nowIso
      });
      if (upsertErr) {
        console.error('Supabase telegram_users upsert error:', upsertErr);
        throw new Error(`Failed to persist telegram user link: ${upsertErr.message}`);
      }
    }

    // Update in user record (which also enforces Supabase persistence)
    const updatedUser = await this.updateUser(userId, { telegram: telegramPayload });

    await this.addTelegramLog({
      id: `tlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      telegramUserId: telegramPayload.telegramUserId,
      action: 'account_linked',
      status: 'success',
      details: `Telegram account @${telegramPayload.telegramUsername || telegramPayload.telegramUserId} linked to Crazy Storyes account`,
      createdAt: nowIso
    });

    return updatedUser || null;
  }

  public async unlinkUserTelegram(userId: string): Promise<User | null> {
    const user = await this.getUserById(userId);
    const tgUserId = user?.telegram?.telegramUserId;
    const nowIso = new Date().toISOString();

    if (isSupabaseConfigured() && supabase) {
      const { error } = await supabase.from('telegram_users').delete().eq('user_id', userId);
      if (error) {
        console.error('Supabase telegram_users delete error:', error);
        throw new Error(`Failed to delete from telegram_users: ${error.message}`);
      }
    }

    const updatedUser = await this.updateUser(userId, { telegram: undefined });

    await this.addTelegramLog({
      id: `tlog_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId,
      telegramUserId: tgUserId,
      action: 'unlinked',
      status: 'success',
      details: `Telegram account unlinked from Crazy Storyes account`,
      createdAt: nowIso
    });

    return updatedUser || null;
  }

  public async getTelegramAccess(userId: string, novelId: string): Promise<TelegramAccessRecord | null> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('telegram_access')
          .select('*')
          .eq('user_id', userId)
          .eq('novel_id', novelId)
          .maybeSingle();

        if (error) {
          console.error('Supabase getTelegramAccess error:', error);
        } else if (data) {
          return rowToTelegramAccess(data);
        }
      } catch (err) {
        console.warn('Supabase getTelegramAccess error:', err);
      }
    }

    const found = this.cache.telegramAccess.find(
      a => a.userId === userId && a.novelId === novelId
    );
    return found || null;
  }

  public async getUserTelegramAccesses(userId: string): Promise<TelegramAccessRecord[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('telegram_access')
          .select('*')
          .eq('user_id', userId)
          .order('created_at', { ascending: false });

        if (!error && data) {
          return data.map(rowToTelegramAccess);
        }
      } catch (err) {
        console.warn('Supabase getUserTelegramAccesses error:', err);
      }
    }

    return this.cache.telegramAccess.filter(a => a.userId === userId);
  }

  public async saveTelegramAccess(access: TelegramAccessRecord): Promise<TelegramAccessRecord> {
    if (isSupabaseConfigured() && supabase) {
      const row = telegramAccessToRow(access);
      const { data, error } = await supabase
        .from('telegram_access')
        .upsert(row)
        .select()
        .single();

      if (error) {
        console.error('Supabase saveTelegramAccess error:', error);
        throw new Error(`Failed to persist telegram access record: ${error.message}`);
      }

      if (data) {
        const saved = rowToTelegramAccess(data);
        const idx = this.cache.telegramAccess.findIndex(a => a.id === access.id || (a.userId === access.userId && a.novelId === access.novelId));
        if (idx !== -1) {
          this.cache.telegramAccess[idx] = saved;
        } else {
          this.cache.telegramAccess.unshift(saved);
        }
        return saved;
      }
    }

    const idx = this.cache.telegramAccess.findIndex(a => a.id === access.id || (a.userId === access.userId && a.novelId === access.novelId));
    if (idx !== -1) {
      this.cache.telegramAccess[idx] = access;
    } else {
      this.cache.telegramAccess.unshift(access);
    }
    return access;
  }

  public async updateTelegramAccess(id: string, patch: Partial<TelegramAccessRecord>): Promise<TelegramAccessRecord | null> {
    const nowIso = new Date().toISOString();
    let updated: TelegramAccessRecord | null = null;

    if (isSupabaseConfigured() && supabase) {
      const rowUpdates: any = { updated_at: nowIso };
      if (patch.status !== undefined) rowUpdates.status = patch.status;
      if (patch.expiresAt !== undefined) rowUpdates.expires_at = patch.expiresAt;
      if (patch.inviteLink !== undefined) rowUpdates.invite_link = patch.inviteLink;

      const { data, error } = await supabase
        .from('telegram_access')
        .update(rowUpdates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Supabase updateTelegramAccess error:', error);
        throw new Error(`Failed to update telegram access record: ${error.message}`);
      }

      if (data) {
        updated = rowToTelegramAccess(data);
      }
    }

    const idx = this.cache.telegramAccess.findIndex(a => a.id === id);
    if (idx !== -1) {
      this.cache.telegramAccess[idx] = {
        ...this.cache.telegramAccess[idx],
        ...patch,
        updatedAt: nowIso
      };
      if (!updated) updated = this.cache.telegramAccess[idx];
    }

    return updated;
  }

  public async getAllTelegramAccesses(): Promise<TelegramAccessRecord[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('telegram_access')
          .select('*')
          .order('created_at', { ascending: false });

        if (!error && data) {
          this.cache.telegramAccess = data.map(rowToTelegramAccess);
          return this.cache.telegramAccess;
        }
      } catch (err) {
        console.warn('Supabase getAllTelegramAccesses error:', err);
      }
    }
    return this.cache.telegramAccess;
  }

  public async addTelegramLog(log: TelegramAccessLog): Promise<TelegramAccessLog> {
    this.cache.telegramAccessLogs.unshift(log);
    if (this.cache.telegramAccessLogs.length > 500) {
      this.cache.telegramAccessLogs.pop();
    }

    if (isSupabaseConfigured() && supabase) {
      try {
        const row = telegramLogToRow(log);
        await supabase.from('telegram_access_logs').insert(row);
      } catch (err) {
        console.warn('Supabase addTelegramLog error:', err);
      }
    }
    return log;
  }

  public async getTelegramLogs(limit = 100): Promise<TelegramAccessLog[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('telegram_access_logs')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(limit);

        if (!error && data) {
          return data.map(rowToTelegramLog);
        }
      } catch (err) {
        console.warn('Supabase getTelegramLogs error:', err);
      }
    }
    return this.cache.telegramAccessLogs.slice(0, limit);
  }

  public async addTelegramPendingOp(op: TelegramPendingOperation): Promise<TelegramPendingOperation> {
    if (isSupabaseConfigured() && supabase) {
      const row = telegramPendingOpToRow(op);
      const { error } = await supabase.from('telegram_pending_operations').insert(row);
      if (error) {
        console.error('Supabase addTelegramPendingOp error:', error);
        throw new Error(`Failed to record telegram pending operation: ${error.message}`);
      }
    }

    const existingIdx = this.cache.telegramPendingOperations.findIndex(
      o => o.channelId === op.channelId && o.telegramUserId === op.telegramUserId && o.status === 'pending'
    );
    if (existingIdx !== -1) {
      this.cache.telegramPendingOperations[existingIdx].retryCount += 1;
      this.cache.telegramPendingOperations[existingIdx].lastError = op.lastError;
      this.cache.telegramPendingOperations[existingIdx].updatedAt = new Date().toISOString();
      return this.cache.telegramPendingOperations[existingIdx];
    }

    this.cache.telegramPendingOperations.push(op);
    return op;
  }

  public async getPendingTelegramOps(): Promise<TelegramPendingOperation[]> {
    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('telegram_pending_operations')
          .select('*')
          .eq('status', 'pending')
          .order('created_at', { ascending: true });

        if (!error && data) {
          return data.map(rowToTelegramPendingOp);
        }
      } catch (err) {
        console.warn('Supabase getPendingTelegramOps error:', err);
      }
    }
    return this.cache.telegramPendingOperations.filter(o => o.status === 'pending');
  }

  public async updateTelegramPendingOp(id: string, patch: Partial<TelegramPendingOperation>): Promise<TelegramPendingOperation | null> {
    const nowIso = new Date().toISOString();
    let updated: TelegramPendingOperation | null = null;

    if (isSupabaseConfigured() && supabase) {
      const rowUpdates: any = { updated_at: nowIso };
      if (patch.status !== undefined) rowUpdates.status = patch.status;
      if (patch.retryCount !== undefined) rowUpdates.retry_count = patch.retryCount;
      if (patch.lastError !== undefined) rowUpdates.last_error = patch.lastError;

      const { data, error } = await supabase
        .from('telegram_pending_operations')
        .update(rowUpdates)
        .eq('id', id)
        .select()
        .single();

      if (error) {
        console.error('Supabase updateTelegramPendingOp error:', error);
        throw new Error(`Failed to update telegram pending operation: ${error.message}`);
      }

      if (data) {
        updated = rowToTelegramPendingOp(data);
      }
    }

    const idx = this.cache.telegramPendingOperations.findIndex(o => o.id === id);
    if (idx !== -1) {
      this.cache.telegramPendingOperations[idx] = {
        ...this.cache.telegramPendingOperations[idx],
        ...patch,
        updatedAt: nowIso
      };
      if (!updated) updated = this.cache.telegramPendingOperations[idx];
    }

    return updated;
  }

  // -------------------------------------------------------------
  // TELEGRAM WEBHOOK UPDATE DEDUPLICATION
  // -------------------------------------------------------------
  private processedUpdateIds = new Set<number>();
  private processedUpdateQueue: number[] = [];

  public async isTelegramUpdateProcessed(updateId: number): Promise<boolean> {
    if (!updateId) return false;
    if (this.processedUpdateIds.has(updateId)) return true;

    if (isSupabaseConfigured() && supabase) {
      try {
        const { data } = await supabase
          .from('telegram_processed_updates')
          .select('update_id')
          .eq('update_id', updateId)
          .maybeSingle();

        if (data?.update_id) {
          this.processedUpdateIds.add(updateId);
          return true;
        }
      } catch (err) {
        // Table may not exist yet if user hasn't run migration; in-memory set handles deduplication
        console.warn('Supabase isTelegramUpdateProcessed check notice:', err);
      }
    }

    return false;
  }

  public async markTelegramUpdateProcessed(updateId: number): Promise<void> {
    if (!updateId) return;
    this.processedUpdateIds.add(updateId);
    this.processedUpdateQueue.push(updateId);
    if (this.processedUpdateQueue.length > 10000) {
      const oldest = this.processedUpdateQueue.shift();
      if (oldest) this.processedUpdateIds.delete(oldest);
    }

    if (isSupabaseConfigured() && supabase) {
      try {
        await supabase
          .from('telegram_processed_updates')
          .insert({ update_id: updateId });
      } catch (err: any) {
        // Ignore duplicate key errors (code 23505)
        if (err?.code !== '23505') {
          console.warn('Supabase markTelegramUpdateProcessed notice:', err);
        }
      }
    }
  }

  // -------------------------------------------------------------
  // USER AUTH & SECURITY AUDIT LOGS
  // -------------------------------------------------------------
  public async addAuthLog(log: UserAuthLog): Promise<UserAuthLog> {
    this.cache.userAuthLogs.unshift(log);
    // Keep in-memory cache bounded
    if (this.cache.userAuthLogs.length > 5000) {
      this.cache.userAuthLogs.pop();
    }

    if (isSupabaseConfigured() && supabase) {
      try {
        const row = authLogToRow(log);
        const { error } = await supabase.from('user_auth_logs').insert(row);
        if (error) {
          console.warn('Supabase addAuthLog notice:', error.message);
        }
      } catch (err: any) {
        console.warn('Supabase addAuthLog error:', err.message);
      }
    }

    return log;
  }

  public async getAuthLogs(options?: { userId?: string; eventType?: string; limit?: number }): Promise<UserAuthLog[]> {
    const limit = options?.limit || 100;

    if (isSupabaseConfigured() && supabase) {
      try {
        let query = supabase
          .from('user_auth_logs')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(limit);

        if (options?.userId) {
          query = query.eq('user_id', options.userId);
        }
        if (options?.eventType && options.eventType !== 'all') {
          query = query.eq('event_type', options.eventType);
        }

        const { data, error } = await query;
        if (!error && data) {
          return data.map(rowToAuthLog);
        }
      } catch (err: any) {
        console.warn('Supabase getAuthLogs notice, using cache:', err.message);
      }
    }

    let logs = [...this.cache.userAuthLogs];
    if (options?.userId) {
      logs = logs.filter(l => l.userId === options.userId);
    }
    if (options?.eventType && options.eventType !== 'all') {
      logs = logs.filter(l => l.eventType === options.eventType);
    }
    return logs.slice(0, limit);
  }

  // -------------------------------------------------------------
  // REVOKED TOKENS / SESSION REVOCATION
  // -------------------------------------------------------------
  public async revokeToken(record: RevokedToken): Promise<void> {
    this.cache.revokedTokens.push(record);

    if (isSupabaseConfigured() && supabase) {
      try {
        const row = revokedTokenToRow(record);
        const { error } = await supabase.from('revoked_tokens').upsert(row);
        if (error) {
          console.warn('Supabase revokeToken notice:', error.message);
        }
      } catch (err: any) {
        console.warn('Supabase revokeToken error:', err.message);
      }
    }
  }

  public async isTokenRevoked(token: string): Promise<boolean> {
    if (!token) return true;

    const inMemory = this.cache.revokedTokens.find(r => r.token === token);
    if (inMemory) {
      // Check if expired
      if (new Date(inMemory.expiresAt).getTime() < Date.now()) {
        this.cache.revokedTokens = this.cache.revokedTokens.filter(r => r.token !== token);
        return false;
      }
      return true;
    }

    if (isSupabaseConfigured() && supabase) {
      try {
        const { data, error } = await supabase
          .from('revoked_tokens')
          .select('id, expires_at')
          .eq('token', token)
          .maybeSingle();

        if (!error && data) {
          if (new Date(data.expires_at).getTime() < Date.now()) {
            return false;
          }
          return true;
        }
      } catch (err: any) {
        console.warn('Supabase isTokenRevoked notice:', err.message);
      }
    }

    return false;
  }
}

export const db = new Database();

