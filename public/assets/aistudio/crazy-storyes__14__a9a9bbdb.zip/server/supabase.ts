import { createClient, SupabaseClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import { 
  Novel, 
  Chapter, 
  User, 
  PaymentRequest, 
  MembershipPlan, 
  SiteSettings, 
  SupportTicket,
  TelegramAccessRecord,
  TelegramLinkCode,
  TelegramAccessLog,
  TelegramPendingOperation,
  UserAuthLog,
  RevokedToken
} from './types.js';

dotenv.config();

const SUPABASE_URL = process.env.SUPABASE_URL || '';
const SUPABASE_KEY = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_KEY || '';

export let supabase: SupabaseClient | null = null;

if (SUPABASE_URL && SUPABASE_KEY && !SUPABASE_URL.includes('your-project-id')) {
  try {
    supabase = createClient(SUPABASE_URL, SUPABASE_KEY, {
      auth: {
        persistSession: false,
        autoRefreshToken: false
      }
    });
    console.log('✅ Supabase client successfully initialized with URL:', SUPABASE_URL);
  } catch (err) {
    console.warn('⚠️ Failed to initialize Supabase client:', err);
    supabase = null;
  }
} else {
  console.log('ℹ️ SUPABASE_URL / SUPABASE_KEY not yet configured in environment. Using in-memory database store (zero JSON file writes).');
}

export function isSupabaseConfigured(): boolean {
  return supabase !== null;
}

export interface SupabaseHealth {
  configured: boolean;
  connected: boolean;
  hasUrl: boolean;
  hasKey: boolean;
  projectDomain?: string;
  latencyMs?: number;
  testedAt: string;
  tablesStatus?: Record<string, boolean>;
  error?: string;
}

/**
 * Tests the real live connection to Supabase via a safe read query.
 * Verifies key tables presence and measures roundtrip latency.
 * Never exposes credentials, passwords, or full API keys.
 */
export async function checkSupabaseConnection(): Promise<SupabaseHealth> {
  const hasUrl = Boolean(SUPABASE_URL && !SUPABASE_URL.includes('your-project-id') && SUPABASE_URL.startsWith('http'));
  const hasKey = Boolean(SUPABASE_KEY && SUPABASE_KEY.length > 20);

  let projectDomain = '';
  if (hasUrl) {
    try {
      projectDomain = new URL(SUPABASE_URL).hostname;
    } catch {
      projectDomain = 'invalid-url';
    }
  }

  if (!hasUrl || !hasKey || !supabase) {
    return {
      configured: false,
      connected: false,
      hasUrl,
      hasKey,
      projectDomain: projectDomain || undefined,
      testedAt: new Date().toISOString(),
      error: !hasUrl
        ? 'SUPABASE_URL वातावरण चर (env var) अनुपलब्ध या अमान्य है'
        : 'SUPABASE_SERVICE_ROLE_KEY / SUPABASE_KEY वातावरण चर अनुपलब्ध है',
    };
  }

  const start = Date.now();
  try {
    // 1. Safe read-only query on site_settings
    const { data, error } = await supabase.from('site_settings').select('id').limit(1);
    const latencyMs = Date.now() - start;

    if (error) {
      return {
        configured: true,
        connected: false,
        hasUrl: true,
        hasKey: true,
        projectDomain,
        latencyMs,
        testedAt: new Date().toISOString(),
        error: `Supabase क्वेरी विफल: ${error.message} (कोड: ${error.code || 'UNKNOWN'})`,
      };
    }

    // 2. Check presence of essential tables
    const tableNames = [
      'site_settings',
      'users',
      'novels',
      'chapters',
      'payments',
      'membership_plans',
      'telegram_users',
      'telegram_access',
      'telegram_link_codes',
      'telegram_access_logs',
      'telegram_pending_operations',
      'telegram_processed_updates',
      'user_auth_logs',
      'revoked_tokens',
    ];

    const tablesStatus: Record<string, boolean> = {};
    await Promise.all(
      tableNames.map(async (tbl) => {
        try {
          const { error: tblErr } = await supabase!.from(tbl).select('*', { head: true, count: 'exact' });
          tablesStatus[tbl] = !tblErr;
        } catch {
          tablesStatus[tbl] = false;
        }
      })
    );

    return {
      configured: true,
      connected: true,
      hasUrl: true,
      hasKey: true,
      projectDomain,
      latencyMs,
      testedAt: new Date().toISOString(),
      tablesStatus,
    };
  } catch (err: any) {
    return {
      configured: true,
      connected: false,
      hasUrl: true,
      hasKey: true,
      projectDomain,
      latencyMs: Date.now() - start,
      testedAt: new Date().toISOString(),
      error: `Supabase नेटवर्क कनेक्शन त्रुटि: ${err?.message || 'अज्ञात त्रुटि'}`,
    };
  }
}

// -------------------------------------------------------------
// Row <-> TypeScript Object Mappers (snake_case <-> camelCase)
// -------------------------------------------------------------

export function userToRow(u: User): any {
  return {
    id: u.id,
    name: u.name,
    email: u.email.toLowerCase(),
    password_hash: u.passwordHash,
    role: u.role || 'reader',
    is_blocked: Boolean(u.isBlocked),
    membership: u.membership || { isActive: false },
    bookmarks: u.bookmarks || [],
    reading_history: u.readingHistory || [],
    telegram: u.telegram || null,
    last_login_at: u.lastLoginAt || null,
    last_logout_at: u.lastLogoutAt || null,
    created_at: u.createdAt || new Date().toISOString()
  };
}

export function userPartialToRow(u: Partial<User>): any {
  const row: any = {};
  if (u.name !== undefined) row.name = u.name;
  if (u.email !== undefined) row.email = u.email.toLowerCase();
  if (u.passwordHash !== undefined) row.password_hash = u.passwordHash;
  if (u.role !== undefined) row.role = u.role;
  if (u.isBlocked !== undefined) row.is_blocked = u.isBlocked;
  if (u.membership !== undefined) row.membership = u.membership;
  if (u.bookmarks !== undefined) row.bookmarks = u.bookmarks;
  if (u.readingHistory !== undefined) row.reading_history = u.readingHistory;
  if (u.telegram !== undefined) row.telegram = u.telegram;
  if (u.lastLoginAt !== undefined) row.last_login_at = u.lastLoginAt;
  if (u.lastLogoutAt !== undefined) row.last_logout_at = u.lastLogoutAt;
  return row;
}

export function rowToUser(r: any): User {
  return {
    id: r.id,
    name: r.name,
    email: r.email,
    passwordHash: r.password_hash,
    role: r.role as 'admin' | 'reader',
    isBlocked: Boolean(r.is_blocked),
    membership: r.membership || { isActive: false },
    bookmarks: Array.isArray(r.bookmarks) ? r.bookmarks : [],
    readingHistory: Array.isArray(r.reading_history) ? r.reading_history : [],
    telegram: r.telegram || undefined,
    lastLoginAt: r.last_login_at || undefined,
    lastLogoutAt: r.last_logout_at || undefined,
    createdAt: r.created_at
  };
}

export function novelToRow(n: Novel): any {
  return {
    id: n.id,
    title: n.title,
    hindi_title: n.hindiTitle || null,
    author: n.author || '',
    description: n.description,
    cover_image: n.coverImage,
    categories: n.categories || [],
    tags: n.tags || [],
    is_premium: Boolean(n.isPremium),
    is_published: n.isPublished !== false,
    is_featured: Boolean(n.isFeatured),
    is_trending: Boolean(n.isTrending),
    is_popular: Boolean(n.isPopular),
    views: Number(n.views) || 0,
    rating: Number(n.rating) || 5.0,
    rating_count: Number(n.ratingCount) || 0,
    user_ratings: n.userRatings || {},
    likes: Number(n.likes) || 0,
    liked_by: n.likedBy || [],
    reviews: n.reviews || [],
    total_chapters: Number(n.totalChapters) || 0,
    telegram_channel_privacy: n.telegramChannelPrivacy || (n.telegramChannelLink && !n.telegramChannelId ? 'public' : 'private'),
    telegram_channel_link: n.telegramChannelLink || null,
    telegram_channel_id: n.telegramChannelId || null,
    telegram_channel_name: n.telegramChannelName || null,
    telegram_channel_type: n.telegramChannelType || 'channel',
    telegram_access_type: n.telegramAccessType || (n.isPremium ? 'premium' : 'free'),
    telegram_integration_enabled: Boolean(n.telegramIntegrationEnabled),
    created_at: n.createdAt || new Date().toISOString(),
    updated_at: n.updatedAt || new Date().toISOString()
  };
}

export function novelPartialToRow(n: Partial<Novel>): any {
  const row: any = { updated_at: new Date().toISOString() };
  if (n.title !== undefined) row.title = n.title;
  if (n.hindiTitle !== undefined) row.hindi_title = n.hindiTitle;
  if (n.author !== undefined) row.author = n.author;
  if (n.description !== undefined) row.description = n.description;
  if (n.coverImage !== undefined) row.cover_image = n.coverImage;
  if (n.categories !== undefined) row.categories = n.categories;
  if (n.tags !== undefined) row.tags = n.tags;
  if (n.isPremium !== undefined) row.is_premium = n.isPremium;
  if (n.isPublished !== undefined) row.is_published = n.isPublished;
  if (n.isFeatured !== undefined) row.is_featured = n.isFeatured;
  if (n.isTrending !== undefined) row.is_trending = n.isTrending;
  if (n.isPopular !== undefined) row.is_popular = n.isPopular;
  if (n.views !== undefined) row.views = n.views;
  if (n.rating !== undefined) row.rating = n.rating;
  if (n.ratingCount !== undefined) row.rating_count = n.ratingCount;
  if (n.userRatings !== undefined) row.user_ratings = n.userRatings;
  if (n.likes !== undefined) row.likes = n.likes;
  if (n.likedBy !== undefined) row.liked_by = n.likedBy;
  if (n.reviews !== undefined) row.reviews = n.reviews;
  if (n.totalChapters !== undefined) row.total_chapters = n.totalChapters;
  if (n.telegramChannelPrivacy !== undefined) row.telegram_channel_privacy = n.telegramChannelPrivacy;
  if (n.telegramChannelLink !== undefined) row.telegram_channel_link = n.telegramChannelLink || null;
  if (n.telegramChannelId !== undefined) row.telegram_channel_id = n.telegramChannelId || null;
  if (n.telegramChannelName !== undefined) row.telegram_channel_name = n.telegramChannelName || null;
  if (n.telegramChannelType !== undefined) row.telegram_channel_type = n.telegramChannelType;
  if (n.telegramAccessType !== undefined) row.telegram_access_type = n.telegramAccessType;
  if (n.telegramIntegrationEnabled !== undefined) row.telegram_integration_enabled = n.telegramIntegrationEnabled;
  return row;
}

export function rowToNovel(r: any): Novel {
  return {
    id: r.id,
    title: r.title,
    hindiTitle: r.hindi_title || undefined,
    author: r.author || '',
    description: r.description,
    coverImage: r.cover_image,
    categories: Array.isArray(r.categories) ? r.categories : [],
    tags: Array.isArray(r.tags) ? r.tags : [],
    isPremium: Boolean(r.is_premium),
    isPublished: r.is_published !== false,
    isFeatured: Boolean(r.is_featured),
    isTrending: Boolean(r.is_trending),
    isPopular: Boolean(r.is_popular),
    views: Number(r.views) || 0,
    rating: Number(r.rating) || 5.0,
    ratingCount: Number(r.rating_count) || 0,
    userRatings: r.user_ratings || {},
    likes: Number(r.likes) || 0,
    likedBy: Array.isArray(r.liked_by) ? r.liked_by : [],
    reviews: Array.isArray(r.reviews) ? r.reviews : [],
    totalChapters: Number(r.total_chapters) || 0,
    telegramChannelPrivacy: r.telegram_channel_privacy || (r.telegram_channel_link && !r.telegram_channel_id ? 'public' : 'private'),
    telegramChannelLink: r.telegram_channel_link || undefined,
    telegramChannelId: r.telegram_channel_id || undefined,
    telegramChannelName: r.telegram_channel_name || undefined,
    telegramChannelType: r.telegram_channel_type || undefined,
    telegramAccessType: r.telegram_access_type || undefined,
    telegramIntegrationEnabled: Boolean(r.telegram_integration_enabled),
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}

export function chapterToRow(c: Chapter): any {
  return {
    id: c.id,
    novel_id: c.novelId,
    chapter_number: Number(c.chapterNumber),
    title: c.title,
    content: c.content || '',
    audio_url: c.audioUrl || null,
    audio_duration_seconds: c.audioDurationSeconds || null,
    is_premium: Boolean(c.isPremium),
    is_published: c.isPublished !== false,
    telegram_message_link: c.telegramMessageLink || null,
    telegram_message_id: c.telegramMessageId || null,
    telegram_chat_id: c.telegramChatId || null,
    telegram_destination_type: c.telegramDestinationType || 'channel',
    telegram_audio_access_type: c.telegramAudioAccessType || (c.isPremium ? 'premium' : 'free'),
    telegram_audio_configured: Boolean(c.telegramMessageLink),
    created_at: c.createdAt || new Date().toISOString(),
    updated_at: c.updatedAt || new Date().toISOString()
  };
}

export function chapterPartialToRow(c: Partial<Chapter>): any {
  const row: any = { updated_at: new Date().toISOString() };
  if (c.novelId !== undefined) row.novel_id = c.novelId;
  if (c.chapterNumber !== undefined) row.chapter_number = Number(c.chapterNumber);
  if (c.title !== undefined) row.title = c.title;
  if (c.content !== undefined) row.content = c.content || '';
  if (c.audioUrl !== undefined) row.audio_url = c.audioUrl || null;
  if (c.audioDurationSeconds !== undefined) row.audio_duration_seconds = c.audioDurationSeconds;
  if (c.isPremium !== undefined) row.is_premium = c.isPremium;
  if (c.isPublished !== undefined) row.is_published = c.isPublished;
  if (c.telegramMessageLink !== undefined) {
    row.telegram_message_link = c.telegramMessageLink || null;
    row.telegram_audio_configured = Boolean(c.telegramMessageLink);
  }
  if (c.telegramMessageId !== undefined) row.telegram_message_id = c.telegramMessageId || null;
  if (c.telegramChatId !== undefined) row.telegram_chat_id = c.telegramChatId || null;
  if (c.telegramDestinationType !== undefined) row.telegram_destination_type = c.telegramDestinationType;
  if (c.telegramAudioAccessType !== undefined) row.telegram_audio_access_type = c.telegramAudioAccessType;
  if (c.telegramAudioConfigured !== undefined) row.telegram_audio_configured = c.telegramAudioConfigured;
  return row;
}

export function rowToChapter(r: any): Chapter {
  const hasTgLink = Boolean(r.telegram_message_link);
  return {
    id: r.id,
    novelId: r.novel_id,
    chapterNumber: Number(r.chapter_number),
    title: r.title,
    content: r.content || '',
    audioUrl: r.audio_url || undefined,
    audioDurationSeconds: r.audio_duration_seconds ? Number(r.audio_duration_seconds) : undefined,
    isPremium: Boolean(r.is_premium),
    isPublished: r.is_published !== false,
    telegramMessageLink: r.telegram_message_link || undefined,
    telegramMessageId: r.telegram_message_id ? Number(r.telegram_message_id) : undefined,
    telegramChatId: r.telegram_chat_id || undefined,
    telegramDestinationType: r.telegram_destination_type || 'channel',
    telegramAudioAccessType: r.telegram_audio_access_type || (r.is_premium ? 'premium' : 'free'),
    telegramAudioConfigured: r.telegram_audio_configured !== undefined ? Boolean(r.telegram_audio_configured) : hasTgLink,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}


export function paymentToRow(p: PaymentRequest): any {
  return {
    id: p.id,
    user_id: p.userId,
    user_name: p.userName,
    user_email: p.userEmail,
    item_type: p.itemType,
    item_id: p.itemId,
    item_name: p.itemName,
    amount: Number(p.amount),
    utr_number: p.utrNumber || null,
    payment_proof_url: p.paymentProofUrl || null,
    screenshot_path: p.screenshotPath || null,
    status: p.status || 'pending',
    rejection_reason: p.rejectionReason || null,
    admin_note: p.adminNote || null,
    created_at: p.createdAt || new Date().toISOString(),
    reviewed_at: p.reviewedAt || null,
    reviewed_by: p.reviewedBy || null
  };
}

export function paymentPartialToRow(p: Partial<PaymentRequest>): any {
  const row: any = {};
  if (p.status !== undefined) row.status = p.status;
  if (p.rejectionReason !== undefined) row.rejection_reason = p.rejectionReason;
  if (p.adminNote !== undefined) row.admin_note = p.adminNote;
  if (p.utrNumber !== undefined) row.utr_number = p.utrNumber;
  if (p.screenshotPath !== undefined) row.screenshot_path = p.screenshotPath;
  if (p.reviewedAt !== undefined) row.reviewed_at = p.reviewedAt;
  if (p.reviewedBy !== undefined) row.reviewed_by = p.reviewedBy;
  return row;
}

export function rowToPayment(r: any): PaymentRequest {
  return {
    id: r.id,
    userId: r.user_id,
    userName: r.user_name,
    userEmail: r.user_email,
    itemType: r.item_type as 'membership' | 'novel',
    itemId: r.item_id,
    itemName: r.item_name,
    amount: Number(r.amount),
    utrNumber: r.utr_number || undefined,
    paymentProofUrl: r.payment_proof_url || undefined,
    screenshotPath: r.screenshot_path || undefined,
    status: r.status as 'pending' | 'approved' | 'rejected',
    rejectionReason: r.rejection_reason || undefined,
    adminNote: r.admin_note || undefined,
    createdAt: r.created_at,
    reviewedAt: r.reviewed_at || undefined,
    reviewedBy: r.reviewed_by || undefined
  };
}

export function planToRow(p: MembershipPlan): any {
  return {
    id: p.id,
    name: p.name,
    hindi_name: p.hindiName,
    price: Number(p.price),
    duration_days: Number(p.durationDays),
    description: p.description,
    features: p.features || [],
    is_active: p.isActive !== false,
    badge_text: p.badgeText || null
  };
}

export function rowToPlan(r: any): MembershipPlan {
  return {
    id: r.id,
    name: r.name,
    hindiName: r.hindi_name,
    price: Number(r.price),
    durationDays: Number(r.duration_days),
    description: r.description,
    features: Array.isArray(r.features) ? r.features : [],
    isActive: r.is_active !== false,
    badgeText: r.badge_text || undefined
  };
}

export function settingsToRow(s: SiteSettings): any {
  return {
    id: 'current',
    website_name: s.websiteName,
    tagline: s.tagline,
    admin_email: s.adminEmail,
    upi_id: s.upiId,
    upi_qr_code_url: s.upiQrCodeUrl || null,
    announcement: s.announcement || '',
    announcement_active: s.announcementActive !== false,
    support_email: s.supportEmail,
    support_phone: s.supportPhone,
    enable_ai_assistant: s.enableAiAssistant !== false,
    updated_at: new Date().toISOString()
  };
}

export function settingsPartialToRow(s: Partial<SiteSettings>): any {
  const row: any = { updated_at: new Date().toISOString() };
  if (s.websiteName !== undefined) row.website_name = s.websiteName;
  if (s.tagline !== undefined) row.tagline = s.tagline;
  if (s.adminEmail !== undefined) row.admin_email = s.adminEmail;
  if (s.upiId !== undefined) row.upi_id = s.upiId;
  if (s.upiQrCodeUrl !== undefined) row.upi_qr_code_url = s.upiQrCodeUrl;
  if (s.announcement !== undefined) row.announcement = s.announcement;
  if (s.announcementActive !== undefined) row.announcement_active = s.announcementActive;
  if (s.supportEmail !== undefined) row.support_email = s.supportEmail;
  if (s.supportPhone !== undefined) row.support_phone = s.supportPhone;
  if (s.enableAiAssistant !== undefined) row.enable_ai_assistant = s.enableAiAssistant;
  return row;
}

export function rowToSettings(r: any): SiteSettings {
  return {
    websiteName: r.website_name,
    tagline: r.tagline,
    adminEmail: r.admin_email,
    upiId: r.upi_id,
    upiQrCodeUrl: r.upi_qr_code_url || '',
    announcement: r.announcement || '',
    announcementActive: r.announcement_active !== false,
    supportEmail: r.support_email,
    supportPhone: r.support_phone,
    enableAiAssistant: r.enable_ai_assistant !== false
  };
}

export function ticketToRow(t: SupportTicket): any {
  return {
    id: t.id,
    user_id: t.userId || null,
    user_name: t.userName,
    user_email: t.userEmail,
    category: t.category,
    subject: t.subject,
    message: t.message,
    admin_reply: t.adminReply || null,
    status: t.status || 'open',
    created_at: t.createdAt || new Date().toISOString(),
    replied_at: t.repliedAt || null
  };
}

export function rowToTicket(r: any): SupportTicket {
  return {
    id: r.id,
    userId: r.user_id || undefined,
    userName: r.user_name,
    userEmail: r.user_email,
    category: r.category as 'question' | 'problem' | 'feedback' | 'payment',
    subject: r.subject,
    message: r.message,
    adminReply: r.admin_reply || undefined,
    status: r.status as 'open' | 'answered' | 'closed',
    createdAt: r.created_at,
    repliedAt: r.replied_at || undefined
  };
}

// -------------------------------------------------------------
// Telegram Mappers
// -------------------------------------------------------------

export function telegramAccessToRow(a: TelegramAccessRecord): any {
  return {
    id: a.id,
    user_id: a.userId,
    telegram_user_id: a.telegramUserId,
    novel_id: a.novelId,
    novel_title: a.novelTitle || null,
    channel_id: a.channelId,
    channel_name: a.channelName || null,
    access_type: a.accessType,
    invite_link: a.inviteLink || null,
    status: a.status,
    joined_at: a.joinedAt || new Date().toISOString(),
    expires_at: a.expiresAt || null,
    created_at: a.createdAt || new Date().toISOString(),
    updated_at: a.updatedAt || new Date().toISOString()
  };
}

export function rowToTelegramAccess(r: any): TelegramAccessRecord {
  return {
    id: r.id,
    userId: r.user_id,
    telegramUserId: Number(r.telegram_user_id),
    novelId: r.novel_id,
    novelTitle: r.novel_title || undefined,
    channelId: r.channel_id,
    channelName: r.channel_name || undefined,
    accessType: r.access_type,
    inviteLink: r.invite_link || undefined,
    status: r.status,
    joinedAt: r.joined_at,
    expiresAt: r.expires_at || undefined,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}

export function telegramLinkCodeToRow(c: TelegramLinkCode): any {
  return {
    id: c.id,
    code: c.code,
    user_id: c.userId,
    user_email: c.userEmail,
    user_name: c.userName,
    expires_at: c.expiresAt,
    used_at: c.usedAt || null,
    created_at: c.createdAt || new Date().toISOString()
  };
}

export function rowToTelegramLinkCode(r: any): TelegramLinkCode {
  return {
    id: r.id,
    code: r.code,
    userId: r.user_id,
    userEmail: r.user_email || '',
    userName: r.user_name || '',
    expiresAt: r.expires_at,
    usedAt: r.used_at || undefined,
    createdAt: r.created_at
  };
}

export function telegramLogToRow(l: TelegramAccessLog): any {
  return {
    id: l.id,
    user_id: l.userId,
    telegram_user_id: l.telegramUserId || null,
    channel_id: l.channelId || null,
    novel_id: l.novelId || null,
    action: l.action,
    status: l.status,
    details: l.details || null,
    created_at: l.createdAt || new Date().toISOString()
  };
}

export function rowToTelegramLog(r: any): TelegramAccessLog {
  return {
    id: r.id,
    userId: r.user_id,
    telegramUserId: r.telegram_user_id ? Number(r.telegram_user_id) : undefined,
    channelId: r.channel_id || undefined,
    novelId: r.novel_id || undefined,
    action: r.action,
    status: r.status,
    details: r.details || undefined,
    createdAt: r.created_at
  };
}

export function telegramPendingOpToRow(p: TelegramPendingOperation): any {
  return {
    id: p.id,
    operation_type: p.operationType,
    user_id: p.userId,
    telegram_user_id: p.telegramUserId,
    channel_id: p.channelId,
    novel_id: p.novelId,
    retry_count: p.retryCount || 0,
    last_error: p.lastError || null,
    status: p.status,
    created_at: p.createdAt || new Date().toISOString(),
    updated_at: p.updatedAt || new Date().toISOString()
  };
}

export function rowToTelegramPendingOp(r: any): TelegramPendingOperation {
  return {
    id: r.id,
    operationType: r.operation_type,
    userId: r.user_id,
    telegramUserId: Number(r.telegram_user_id),
    channelId: r.channel_id,
    novelId: r.novel_id,
    retryCount: Number(r.retry_count) || 0,
    lastError: r.last_error || undefined,
    status: r.status,
    createdAt: r.created_at,
    updatedAt: r.updated_at
  };
}

export function authLogToRow(l: UserAuthLog): any {
  return {
    id: l.id,
    user_id: l.userId || null,
    user_email: l.userEmail || null,
    user_name: l.userName || null,
    event_type: l.eventType,
    ip: l.ip || null,
    user_agent: l.userAgent || null,
    device_info: l.deviceInfo || null,
    details: l.details || null,
    created_at: l.createdAt || new Date().toISOString()
  };
}

export function rowToAuthLog(r: any): UserAuthLog {
  return {
    id: r.id,
    userId: r.user_id || undefined,
    userEmail: r.user_email || undefined,
    userName: r.user_name || undefined,
    eventType: r.event_type,
    ip: r.ip || undefined,
    userAgent: r.user_agent || undefined,
    deviceInfo: r.device_info || undefined,
    details: r.details || undefined,
    createdAt: r.created_at
  };
}

export function revokedTokenToRow(t: RevokedToken): any {
  return {
    id: t.id,
    token: t.token,
    user_id: t.userId || null,
    expires_at: t.expiresAt,
    revoked_at: t.revokedAt || new Date().toISOString(),
    reason: t.reason || null
  };
}

export function rowToRevokedToken(r: any): RevokedToken {
  return {
    id: r.id,
    token: r.token,
    userId: r.user_id || undefined,
    expiresAt: r.expires_at,
    revokedAt: r.revoked_at,
    reason: r.reason || undefined
  };
}


